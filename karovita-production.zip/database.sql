-- ====================================================================
-- Karovita Cloud ERP Database Dump (Enterprise Grade - MySQL / MariaDB Compatible)
-- Fully compliant with 12 Core Architectural Standards:
-- 1. Primary Key (id / code)
-- 2. Created At (created_at TIMESTAMP)
-- 3. Updated At (updated_at TIMESTAMP)
-- 4. Deleted At (deleted_at TIMESTAMP - Soft Delete)
-- 5. Status (status VARCHAR(50))
-- 6. Active (is_active TINYINT(1))
-- 7. Complete Business Data Columns
-- 8. Explicit Data Types (BIGINT, DECIMAL, VARCHAR, TEXT, JSON, TINYINT)
-- 9. Not Null Constraints
-- 10. Unique Constraints
-- 11. Default Values
-- 12. Strategic Performance Indexes
-- Generated: 2026-09-08T08:38:28.956Z
-- ====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

-- -------------------------------------------------------------
-- 1. USERS TABLE
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `mobile` VARCHAR(15) NOT NULL,
  `name` VARCHAR(255) NULL,
  `first_name` VARCHAR(191) NULL DEFAULT '',
  `last_name` VARCHAR(191) NULL DEFAULT '',
  `email` VARCHAR(255) NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'user',
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `job_title` VARCHAR(191) NULL DEFAULT '',
  `national_code` VARCHAR(20) NULL DEFAULT NULL,
  `avatar` VARCHAR(255) NULL,
  `onboarding_step` INT NOT NULL DEFAULT 1,
  `has_used_trial` TINYINT(1) NOT NULL DEFAULT 0,
  `onboarding_completed_at` TIMESTAMP NULL DEFAULT NULL,
  `last_login_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_mobile_unique` (`mobile`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_is_active` (`is_active`),
  KEY `idx_users_created_at` (`created_at`),
  KEY `idx_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `mobile`, `name`, `first_name`, `last_name`, `email`, `role`, `status`, `is_active`, `job_title`, `avatar`, `onboarding_step`, `onboarding_completed_at`, `last_login_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '09111273476', 'اردلان داوودی', 'اردلان', 'داوودی', 'ardalan.davodi@gmail.com', 'admin', 'active', 1, 'مدیر ارشد و مالک سیستم', NULL, 4, '2026-09-16 05:44:55', NULL, '2026-08-30 10:01:55', '2026-09-16 05:44:55', NULL),
(5, '09113137018', 'محمد منیری', 'محمد', 'منیری', '', 'admin', 'active', 1, 'مدیر مالی', NULL, 3, NULL, NULL, '2026-09-14 05:20:40', '2026-09-14 05:50:57', NULL),
(6, '09113175211', 'سعید نظریان', 'سعید', 'نظریان', '', 'user', 'active', 1, 'مدیرعامل', NULL, 4, '2026-09-14 08:42:28', NULL, '2026-09-14 08:40:32', '2026-09-14 08:42:28', NULL),
(8, '09210895901', 'فاطمه قلی پور', 'فاطمه', 'قلی پور', '', 'user', 'active', 1, 'سایر', NULL, 3, NULL, NULL, '2026-09-15 10:44:01', '2026-09-15 10:44:52', NULL),
(10, '09113162780', 'میلاد نیکویی', 'میلاد', 'نیکویی', '', 'user', 'active', 1, '', NULL, 2, NULL, NULL, '2026-09-15 13:19:40', '2026-09-15 13:20:08', NULL),
(14, '09114995930', 'متین شریعتی', 'متین', 'شریعتی', '', 'admin', 'active', 1, 'مدیرعامل', NULL, 4, '2026-09-16 10:56:30', NULL, '2026-09-16 07:00:59', '2026-09-16 11:00:02', NULL),
(15, '09128066062', 'pourya ahmadi', 'نامتندممد', 'ahmadi', '', 'admin', 'active', 1, 'مشاور', NULL, 4, '2026-09-16 07:18:34', NULL, '2026-09-16 07:06:40', '2026-09-16 08:54:15', NULL),
(16, '09339945047', 'pourya ahmadi', 'pourya', 'ahmadi', '', 'user', 'active', 1, 'مدیر فنی / IT', NULL, 3, NULL, NULL, '2026-09-16 08:57:01', '2026-09-16 08:57:09', NULL),
(20, '09352913139', 'کارشناس پشتیبانی', 'کارشناس', 'پشتیبانی', '', 'support', 'active', 1, 'کارشناس پشتیبانی', NULL, 3, '2026-09-19 11:33:52', NULL, '2026-09-19 11:33:42', '2026-09-19 11:52:34', NULL)
ON DUPLICATE KEY UPDATE
  `role` = VALUES(`role`),
  `status` = VALUES(`status`),
  `is_active` = VALUES(`is_active`),
  `job_title` = VALUES(`job_title`),
  `updated_at` = VALUES(`updated_at`);

-- -------------------------------------------------------------
-- 2. COMPANIES TABLE (Legal & Enterprise Business Profile)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `company_name` VARCHAR(255) NULL,
  `subdomain` VARCHAR(100) NULL,
  `economic_code` VARCHAR(50) NULL,
  `national_id` VARCHAR(20) NULL,
  `registration_num` VARCHAR(50) NULL,
  `registration_number` VARCHAR(50) NULL,
  `postal_code` VARCHAR(20) NULL,
  `province` VARCHAR(100) NULL,
  `city` VARCHAR(100) NULL,
  `industry` VARCHAR(100) NULL,
  `employee_count` INT NOT NULL DEFAULT 1,
  `phone` VARCHAR(30) NULL,
  `address` TEXT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_companies_user_id` (`user_id`),
  KEY `idx_companies_national_id` (`national_id`),
  KEY `idx_companies_economic_code` (`economic_code`),
  KEY `idx_companies_status` (`status`),
  KEY `idx_companies_is_active` (`is_active`),
  KEY `idx_companies_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `companies` (`id`, `user_id`, `name`, `company_name`, `subdomain`, `economic_code`, `national_id`, `registration_num`, `registration_number`, `postal_code`, `province`, `city`, `industry`, `employee_count`, `phone`, `address`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 5, 'fdgdfg', 'fdgdfg', '', '', '', '', NULL, '', '', '', 'خدمات حرفه‌ای', 1, '', '', 'active', 1, '2026-09-14 05:21:03', '2026-09-14 05:21:03', NULL),
(5, 6, 'فرتاک', 'فرتاک', '', '', '', '', NULL, '', '', '', 'خدمات حرفه‌ای', 1, '', '', 'active', 1, '2026-09-14 08:40:52', '2026-09-14 08:40:52', NULL),
(6, 8, 'نیکروشاپ', 'نیکروشاپ', '', '', '', '', NULL, '', '', '', 'فروش و بازرگانی', 1, '', '', 'active', 1, '2026-09-15 10:44:52', '2026-09-15 10:44:52', NULL),
(11, 14, 'تست', 'تست', '', '', '', '', NULL, '', '', '', 'فروش و بازرگانی', 1, '', '', 'active', 1, '2026-09-16 07:01:02', '2026-09-16 07:01:02', NULL),
(12, 15, 'یه چیزی', 'یه چیزی', '', '', '2051662351000', '', NULL, '', 'تهران', 'تهران', 'فناوری اطلاعات و نرم‌افزار', 1, '', '', 'active', 1, '2026-09-16 07:07:43', '2026-09-16 07:24:16', NULL),
(13, 16, 'یه چیزی', 'یه چیزی', '', '', '', '', NULL, '', '', '', 'فناوری اطلاعات و نرم‌افزار', 1, '', '', 'active', 1, '2026-09-16 08:57:09', '2026-09-16 08:57:09', NULL);

-- -------------------------------------------------------------
-- 3. PACKAGES TABLE (Subscription Plans)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `packages`;
CREATE TABLE `packages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `price` BIGINT NOT NULL DEFAULT 0,
  `duration_days` INT NOT NULL DEFAULT 30,
  `usage_limit` INT NULL,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `features` JSON NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `packages_slug_unique` (`slug`),
  KEY `idx_packages_status` (`status`),
  KEY `idx_packages_is_active` (`is_active`),
  KEY `idx_packages_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `packages` (`id`, `name`, `slug`, `description`, `price`, `duration_days`, `usage_limit`, `is_featured`, `is_active`, `features`, `created_at`) VALUES
(1, 'آزمایشی ۵ روزه کارویتا', 'trial', 'دسترسی آزمایشی برای بررسی امکانات', 0, 5, NULL, 0, 1, '["تمام امکانات پایه","بدون نیاز به پرداخت","فعال‌سازی فوری"]', '2026-08-30T13:31:55.066Z'),
(2, 'تیک‌آف کارویتا', 'takeoff', 'مناسب تیم‌های کوچک و استارتاپ‌ها', 799000, 30, 1000, 1, 1, '["مدیریت مشتریان","مدیریت فروش","ذخیره‌سازی ۷ گیگابایت"]', '2026-08-30T13:31:55.066Z'),
(3, 'پرواز کارویتا', 'flight', 'مناسب کسب‌وکارهای در حال رشد', 1099000, 30, 3000, 0, 1, '["اتوماسیون فروش","گزارش‌های پیشرفته","ذخیره‌سازی ۱۵ گیگابایت"]', '2026-08-30T13:31:55.066Z'),
(4, 'صعود کارویتا', 'climb', 'مناسب سازمان‌ها و شرکت‌های بزرگ', 4899000, 365, NULL, 0, 1, '["تمام ماژول‌ها","کاربر نامحدود","پشتیبانی اختصاصی"]', '2026-08-30T13:31:55.066Z');

-- -------------------------------------------------------------
-- 4. PRICING MODULES TABLE (All ERP Modules)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `pricing_modules`;
CREATE TABLE `pricing_modules` (
  `id` VARCHAR(50) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `category` VARCHAR(50) NOT NULL DEFAULT 'general',
  `price` BIGINT NOT NULL DEFAULT 0,
  `dependencies` JSON NULL,
  `industries` JSON NULL,
  `description` TEXT NULL,
  `is_core` TINYINT(1) NOT NULL DEFAULT 0,
  `is_recommended` TINYINT(1) NOT NULL DEFAULT 0,
  `icon` VARCHAR(50) NOT NULL DEFAULT 'Package',
  `badge` VARCHAR(50) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pricing_modules_category` (`category`),
  KEY `idx_pricing_modules_status` (`status`),
  KEY `idx_pricing_modules_is_active` (`is_active`),
  KEY `idx_pricing_modules_price` (`price`),
  KEY `idx_pricing_modules_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pricing_modules` (`id`, `title`, `category`, `price`, `dependencies`, `industries`, `description`, `is_core`, `is_recommended`, `icon`, `badge`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
('account', 'حسابداری', 'عمومی', 300000, '["mail", "contacts", "sale"]', '[]', '', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-14 05:54:49', NULL),
('activities', 'اقدامات و پیگیری‌ها', 'عمومی', 90000, '["mail", "calendar", "contacts", "project"]', '["education_academy", "distribution_logistics", "immigration"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:07', NULL),
('ai_assistant', 'هوش مصنوعی', 'productivity', 250000, '[]', '[]', 'نگارش هوشمند متون، تحلیل روند فروش و پیش‌بینی تقاضا', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('calendar', 'گاهشمار', 'عمومی', 0, '["mail", "contacts", "im_livechat", "hr_holidays", "hr_recruitment", "hr_attendance", "activities", "hr", "survey", "project", "sale", "stock", "survey_feedback", "loyalty", "knowledge", "helpdesk", "hr_payroll", "hr_timesheet", "ai_assistant", "account", "crm"]', '["medical_pharma", "it_software", "healthcare_clinic", "immigration", "legal_law", "real_estate", "services_maintenance", "manufacturing", "insurance_agency", "contracting_projects", "advertising_marketing", "commerce_trade", "distribution_logistics", "education_academy", "consulting_finance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:38:17', NULL),
('contacts', 'مخاطبان و اشخاص', 'عمومی', 0, '["crm", "account", "ai_assistant", "hr_timesheet", "hr_payroll", "knowledge", "loyalty", "im_livechat", "helpdesk", "sale", "stock", "survey_feedback", "hr", "survey", "project", "hr_attendance", "calendar", "activities", "hr_holidays", "hr_recruitment", "mail"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:38:51', NULL),
('crm', 'مدیریت ارتباط با مشتری (CRM)', 'عمومی', 350000, '["mail", "calendar", "contacts"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:40:18', NULL),
('helpdesk', 'پشتیبانی', 'management', 250000, '[]', '[]', 'میز خدمت، پورتال تیکت مشتریان و زمان‌بندی پاسخگویی SLA', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-13 11:47:54', NULL),
('hr', 'کارمندان', 'عمومی', 130000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "commerce_trade", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:42:25', NULL),
('hr_attendance', 'حضور و غیاب پرسنل', 'عمومی', 100000, '["mail", "calendar", "contacts", "hr"]', '["contracting_projects", "education_academy", "healthcare_clinic", "it_software", "manufacturing"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:42:48', NULL),
('hr_holidays', 'مرخصی و ماموریت', 'عمومی', 50000, '["hr", "contacts", "calendar", "mail"]', '["real_estate", "medical_pharma", "healthcare_clinic", "insurance_agency", "immigration", "legal_law"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:33', NULL),
('hr_payroll', 'حقوق و دستمزد', 'hr', 250000, '["hr"]', '[]', 'محاسبه فیش حقوقی مطابق قانون کار، دیسکت بیمه و فایل بانکی', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('hr_recruitment', 'استخدام و جذب نیرو', 'عمومی', 80000, '["hr", "mail", "calendar", "contacts"]', '["advertising_marketing", "education_academy", "contracting_projects", "consulting_finance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:19', NULL),
('hr_timesheet', 'برگه ساعت کارکرد', 'management', 250000, '["project"]', '[]', 'ثبت کارکرد ساعتی پرسنل بر روی تسک‌ها و کنترل راندمان', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('im_livechat', 'چت انلاین', 'marketing', 250000, '[]', '[]', 'ابزارک گفتگوی زنده با کاربران و مشتریان روی وب‌سایت', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('knowledge', 'دانش', 'productivity', 250000, '[]', '[]', 'پایگاه دانش سازمانی، راهنماهای آموزشی و ویکی مستندات تیمی', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('loyalty', 'باشگاه مشتریان', 'sales', 250000, '["sale"]', '[]', 'امتیاز خرید، بن‌های هدیه، کوپن تخفیف و کارت وفاداری', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('mail', 'گفتگو', 'عمومی', 0, '["contacts", "crm", "helpdesk", "hr_payroll", "account", "ai_assistant", "hr_timesheet", "knowledge", "loyalty", "im_livechat", "sale", "project", "survey", "stock", "survey_feedback", "hr", "activities", "hr_attendance", "hr_recruitment", "hr_holidays", "calendar"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:39:17', NULL),
('mass_mailing_sms', 'پیامک', 'marketing', 100000, '[]', '[]', 'سامانه ارسال پیامک انبوه اطلاع‌رسانی، تخفیف و مناسبتی', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-13 11:49:35', NULL),
('project', 'پروژه', 'عمومی', 150000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "consulting_finance", "contracting_projects", "immigration", "it_software", "legal_law", "manufacturing", "medical_pharma", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:41:38', NULL),
('sale', 'فروش', 'عمومی', 250000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "immigration", "insurance_agency", "it_software", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 05:44:36', NULL),
('stock', 'انبار و کالا', 'logistics', 250000, '[]', '[]', 'کاردکس کالا، کنترل موجودی چندانباره و نقطه سفارش خودکار', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('survey', 'فرم‌ساز', 'عمومی', 150000, '["contacts", "crm", "calendar", "mail"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', 0, 0, 'Package', NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 05:44:43', NULL),
('survey_feedback', 'نظرسنجی ها', 'marketing', 250000, '[]', '[]', 'پرسشنامه‌های آنلاین و سنجش سطح رضایت مشتریان و پرسنل', 0, 0, 'Package', NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL);

-- -------------------------------------------------------------
-- 5. ERP MODULES TABLE (ERP Core Modules Mirror)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `erp_modules`;
CREATE TABLE `erp_modules` (
  `id` VARCHAR(50) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `category` VARCHAR(50) NOT NULL DEFAULT 'general',
  `price` BIGINT NOT NULL DEFAULT 0,
  `dependencies` JSON NULL,
  `industries` JSON NULL,
  `description` TEXT NULL,
  `icon` VARCHAR(50) NULL,
  `badge` VARCHAR(50) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_erp_modules_category` (`category`),
  KEY `idx_erp_modules_status` (`status`),
  KEY `idx_erp_modules_is_active` (`is_active`),
  KEY `idx_erp_modules_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `erp_modules` (`id`, `title`, `category`, `price`, `dependencies`, `industries`, `description`, `icon`, `badge`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
('account', 'حسابداری', 'عمومی', 300000, '["mail", "contacts", "sale"]', '[]', '', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-14 05:54:49', NULL),
('activities', 'اقدامات و پیگیری‌ها', 'عمومی', 90000, '["mail", "calendar", "contacts", "project"]', '["education_academy", "distribution_logistics", "immigration"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:07', NULL),
('ai_assistant', 'هوش مصنوعی', 'productivity', 250000, '[]', '[]', 'نگارش هوشمند متون، تحلیل روند فروش و پیش‌بینی تقاضا', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('calendar', 'گاهشمار', 'عمومی', 0, '["mail", "contacts", "im_livechat", "hr_holidays", "hr_recruitment", "hr_attendance", "activities", "hr", "survey", "project", "sale", "stock", "survey_feedback", "loyalty", "knowledge", "helpdesk", "hr_payroll", "hr_timesheet", "ai_assistant", "account", "crm"]', '["medical_pharma", "it_software", "healthcare_clinic", "immigration", "legal_law", "real_estate", "services_maintenance", "manufacturing", "insurance_agency", "contracting_projects", "advertising_marketing", "commerce_trade", "distribution_logistics", "education_academy", "consulting_finance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:38:17', NULL),
('contacts', 'مخاطبان و اشخاص', 'عمومی', 0, '["crm", "account", "ai_assistant", "hr_timesheet", "hr_payroll", "knowledge", "loyalty", "im_livechat", "helpdesk", "sale", "stock", "survey_feedback", "hr", "survey", "project", "hr_attendance", "calendar", "activities", "hr_holidays", "hr_recruitment", "mail"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:38:51', NULL),
('crm', 'مدیریت ارتباط با مشتری (CRM)', 'عمومی', 350000, '["mail", "calendar", "contacts"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:40:18', NULL),
('helpdesk', 'پشتیبانی', 'management', 250000, '[]', '[]', 'میز خدمت، پورتال تیکت مشتریان و زمان‌بندی پاسخگویی SLA', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-13 11:47:54', NULL),
('hr', 'کارمندان', 'عمومی', 130000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "commerce_trade", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:42:25', NULL),
('hr_attendance', 'حضور و غیاب پرسنل', 'عمومی', 100000, '["mail", "calendar", "contacts", "hr"]', '["contracting_projects", "education_academy", "healthcare_clinic", "it_software", "manufacturing"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:42:48', NULL),
('hr_holidays', 'مرخصی و ماموریت', 'عمومی', 50000, '["hr", "contacts", "calendar", "mail"]', '["real_estate", "medical_pharma", "healthcare_clinic", "insurance_agency", "immigration", "legal_law"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:33', NULL),
('hr_payroll', 'حقوق و دستمزد', 'hr', 250000, '["hr"]', '[]', 'محاسبه فیش حقوقی مطابق قانون کار، دیسکت بیمه و فایل بانکی', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('hr_recruitment', 'استخدام و جذب نیرو', 'عمومی', 80000, '["hr", "mail", "calendar", "contacts"]', '["advertising_marketing", "education_academy", "contracting_projects", "consulting_finance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:47:19', NULL),
('hr_timesheet', 'برگه ساعت کارکرد', 'management', 250000, '["project"]', '[]', 'ثبت کارکرد ساعتی پرسنل بر روی تسک‌ها و کنترل راندمان', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('im_livechat', 'چت انلاین', 'marketing', 250000, '[]', '[]', 'ابزارک گفتگوی زنده با کاربران و مشتریان روی وب‌سایت', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('knowledge', 'دانش', 'productivity', 250000, '[]', '[]', 'پایگاه دانش سازمانی، راهنماهای آموزشی و ویکی مستندات تیمی', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('loyalty', 'باشگاه مشتریان', 'sales', 250000, '["sale"]', '[]', 'امتیاز خرید، بن‌های هدیه، کوپن تخفیف و کارت وفاداری', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('mail', 'گفتگو', 'عمومی', 0, '["contacts", "crm", "helpdesk", "hr_payroll", "account", "ai_assistant", "hr_timesheet", "knowledge", "loyalty", "im_livechat", "sale", "project", "survey", "stock", "survey_feedback", "hr", "activities", "hr_attendance", "hr_recruitment", "hr_holidays", "calendar"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:39:17', NULL),
('mass_mailing_sms', 'پیامک', 'marketing', 100000, '[]', '[]', 'سامانه ارسال پیامک انبوه اطلاع‌رسانی، تخفیف و مناسبتی', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-13 11:49:35', NULL),
('project', 'پروژه', 'عمومی', 150000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "consulting_finance", "contracting_projects", "immigration", "it_software", "legal_law", "manufacturing", "medical_pharma", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-15 14:41:38', NULL),
('sale', 'فروش', 'عمومی', 250000, '["mail", "contacts", "calendar"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "immigration", "insurance_agency", "it_software", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 05:44:36', NULL),
('stock', 'انبار و کالا', 'logistics', 250000, '[]', '[]', 'کاردکس کالا، کنترل موجودی چندانباره و نقطه سفارش خودکار', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL),
('survey', 'فرم‌ساز', 'عمومی', 150000, '["contacts", "crm", "calendar", "mail"]', '["advertising_marketing", "commerce_trade", "consulting_finance", "contracting_projects", "distribution_logistics", "education_academy", "healthcare_clinic", "immigration", "insurance_agency", "it_software", "legal_law", "manufacturing", "medical_pharma", "real_estate", "services_maintenance"]', '', NULL, NULL, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 05:44:43', NULL),
('survey_feedback', 'نظرسنجی ها', 'marketing', 250000, '[]', '[]', 'پرسشنامه‌های آنلاین و سنجش سطح رضایت مشتریان و پرسنل', NULL, NULL, 'active', 0, '2026-09-10 06:10:07', '2026-09-10 06:10:07', NULL);

-- -------------------------------------------------------------
-- 6. INDUSTRY PRESETS TABLE (Tabs & Business Presets)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `industry_presets`;
CREATE TABLE `industry_presets` (
  `id` VARCHAR(50) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `category` VARCHAR(50) NOT NULL DEFAULT 'صنف',
  `icon` VARCHAR(50) NULL DEFAULT 'Layers',
  `description` TEXT NULL,
  `mandatory_modules` JSON NULL,
  `default_modules` JSON NULL,
  `popular` TINYINT(1) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_industry_presets_status` (`status`),
  KEY `idx_industry_presets_is_active` (`is_active`),
  KEY `idx_industry_presets_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `industry_presets` (`id`, `title`, `category`, `icon`, `description`, `mandatory_modules`, `default_modules`, `popular`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
('advertising_marketing', 'تبلیغات، مارکتینگ و روابط عمومی', 'صنف', 'Megaphone', '', '["calendar", "contacts", "mail", "crm"]', '["contacts", "crm", "project", "sale", "calendar", "activities", "mass_mailing_sms", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:16:02', NULL),
('commerce_trade', 'بازرگانی، واردات و صادرات', 'صنف', 'Ship', '', '["sale", "activities", "contacts", "mail", "calendar"]', '["sale", "contacts", "crm", "hr", "activities", "mass_mailing_sms", "mail", "calendar"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:15:12', NULL),
('consulting_finance', 'مشاوره مدیریت و خدمات مالی', 'صنف', 'BarChart3', '', '["activities", "project", "calendar", "contacts", "mail"]', '["contacts", "crm", "project", "calendar", "survey", "hr", "activities", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:17:05', NULL),
('contracting_projects', 'پیمانکاری و پروژه‌محور', 'صنف', 'Building2', '', '["project", "activities", "contacts", "sale", "calendar", "mail"]', '["project", "hr", "hr_attendance", "activities", "hr_holidays", "contacts", "sale", "calendar", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:18:03', NULL),
('distribution_logistics', 'پخش، انبارداری و توزیع', 'صنف', 'Truck', '', '["activities", "contacts", "calendar", "mail"]', '["sale", "contacts", "activities", "mass_mailing_sms", "hr", "hr_holidays", "hr_attendance", "calendar", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:18:37', NULL),
('education_academy', 'آموزشگاه‌ها و مراکز علمی', 'صنف', 'GraduationCap', '', '["crm", "survey", "calendar", "contacts", "mail"]', '["contacts", "crm", "hr", "calendar", "survey", "activities", "mass_mailing_sms", "mail", "project"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:19:59', NULL),
('healthcare_clinic', 'کلینیک، سلامت و درمان', 'صنف', 'Stethoscope', '', '["survey", "calendar", "activities", "contacts", "hr", "hr_attendance", "project", "mail"]', '["contacts", "hr", "hr_attendance", "calendar", "survey", "mass_mailing_sms", "activities", "project", "mail", "hr_recruitment", "hr_holidays"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:21:04', NULL),
('immigration', 'مؤسسات مهاجرتی', 'صنف', 'Plane', '', '["crm", "calendar", "contacts", "mail"]', '["contacts", "crm", "calendar", "survey", "activities", "mass_mailing_sms", "mail", "project"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:27:26', NULL),
('insurance_agency', 'بیمه و نمایندگی‌ها', 'صنف', 'ShieldCheck', '', '["crm", "sale", "calendar", "contacts", "mail"]', '["contacts", "crm", "sale", "calendar", "survey", "activities", "mass_mailing_sms", "project", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:24:07', NULL),
('it_software', 'فناوری اطلاعات و نرم‌افزار', 'صنف', 'Laptop', '', '["project", "activities", "mail", "calendar", "contacts"]', '["mail", "crm", "project", "hr", "activities", "hr_holidays", "hr_recruitment", "calendar", "contacts"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:25:19', NULL),
('legal_law', 'مؤسسات حقوقی و داوری', 'صنف', 'Scale', '', '["crm", "calendar", "survey", "contacts", "mail"]', '["contacts", "crm", "project", "survey", "activities", "calendar", "mass_mailing_sms", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:26:54', NULL),
('manufacturing', 'تولیدی و صنعتی', 'صنف', 'Factory', '', '["sale", "activities", "contacts", "project", "calendar", "mail"]', '["contacts", "sale", "hr", "hr_attendance", "activities", "hr_holidays", "project", "calendar", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:28:07', NULL),
('medical_pharma', 'تجهیزات پزشکی و دارویی', 'صنف', 'Pill', '', '["crm", "sale", "contacts", "calendar", "mail"]', '["sale", "contacts", "crm", "hr_holidays", "activities", "mass_mailing_sms", "project", "calendar", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:30:52', NULL),
('real_estate', 'املاک و مستغلات', 'صنف', 'Building', '', '["crm", "calendar", "survey", "contacts", "mail"]', '["contacts", "crm", "mass_mailing_sms", "calendar", "survey", "activities", "project", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:31:29', NULL),
('services_maintenance', 'خدماتی، تأسیساتی و تعمیرات', 'صنف', 'Wrench', '', '["activities", "project", "sale", "contacts", "calendar", "mail"]', '["contacts", "project", "hr", "activities", "mass_mailing_sms", "sale", "hr_attendance", "calendar", "mail"]', 0, 'active', 1, '2026-09-10 06:10:07', '2026-09-16 10:33:41', NULL);

-- -------------------------------------------------------------
-- 7. CONFIGURATOR SETTINGS TABLE (Global Pricing Rules)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `configurator_settings`;
CREATE TABLE `configurator_settings` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `base_user_limit` INT NOT NULL DEFAULT 1,
  `extra_user_price` BIGINT NOT NULL DEFAULT 800000,
  `yearly_multiplier` DECIMAL(5,2) NOT NULL DEFAULT 10.20,
  `semiannual_multiplier` DECIMAL(5,2) NOT NULL DEFAULT 6.00,
  `quarterly_multiplier` DECIMAL(5,2) NOT NULL DEFAULT 3.00,
  `step_users_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `step_modules_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `configurator_settings` (`id`, `base_user_limit`, `extra_user_price`, `yearly_multiplier`, `semiannual_multiplier`, `quarterly_multiplier`, `step_users_enabled`, `step_modules_enabled`) VALUES
(1, 1, 150000, 10, 6, 3, 1, 1)
ON DUPLICATE KEY UPDATE
  `base_user_limit` = VALUES(`base_user_limit`),
  `extra_user_price` = VALUES(`extra_user_price`),
  `yearly_multiplier` = VALUES(`yearly_multiplier`),
  `semiannual_multiplier` = VALUES(`semiannual_multiplier`),
  `quarterly_multiplier` = VALUES(`quarterly_multiplier`),
  `step_users_enabled` = VALUES(`step_users_enabled`),
  `step_modules_enabled` = VALUES(`step_modules_enabled`);

-- -------------------------------------------------------------
-- 8. COUPONS TABLE (Discount Engine)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `code` VARCHAR(50) NOT NULL,
  `discount_type` VARCHAR(20) NOT NULL DEFAULT 'percent',
  `discount_value` BIGINT NOT NULL DEFAULT 0,
  `min_order_amount` BIGINT NULL DEFAULT 0,
  `max_discount_amount` BIGINT NULL,
  `expires_at` TIMESTAMP NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`code`),
  KEY `idx_coupons_status` (`status`),
  KEY `idx_coupons_is_active` (`is_active`),
  KEY `idx_coupons_expires_at` (`expires_at`),
  KEY `idx_coupons_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `coupons` (`code`, `discount_type`, `discount_value`, `min_order_amount`, `max_discount_amount`, `is_active`) VALUES
('KAROVITA20', 'percent', 20, NULL, NULL, 1),
('WELCOME', 'fixed', 500000, 2000000, NULL, 1),
('OFF10', 'percent', 10, NULL, NULL, 1);

-- -------------------------------------------------------------
-- 9. DEPARTMENTS TABLE (Support Departments)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NOT NULL,
  `icon` VARCHAR(100) NULL DEFAULT 'Layers',
  `description` TEXT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_departments_status` (`status`),
  KEY `idx_departments_is_active` (`is_active`),
  KEY `idx_departments_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departments` (`id`, `name`, `description`) VALUES
(1, 'فروش', NULL),
(2, 'پشتیبانی فنی', NULL),
(3, 'مالی', NULL),
(4, 'سایر موارد', NULL);

-- -------------------------------------------------------------
-- 10. ORDERS TABLE (Customer Orders & Invoices)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `package_id` BIGINT UNSIGNED NULL,
  `order_number` VARCHAR(50) NOT NULL,
  `amount` BIGINT NOT NULL DEFAULT 0,
  `subtotal` BIGINT NOT NULL DEFAULT 0,
  `vat_rate` DECIMAL(5,2) NOT NULL DEFAULT 0.10,
  `vat_amount` BIGINT NOT NULL DEFAULT 0,
  `final_amount` BIGINT NOT NULL DEFAULT 0,
  `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
  `is_paid` TINYINT(1) NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `tracking_code` VARCHAR(100) NULL,
  `paid_at` TIMESTAMP NULL,
  `coupon_code` VARCHAR(50) NULL,
  `discount_amount` BIGINT NOT NULL DEFAULT 0,
  `module_ids` JSON NULL,
  `user_count` INT NOT NULL DEFAULT 1,
  `billing_period` VARCHAR(50) NOT NULL DEFAULT 'yearly',
  `package_name` VARCHAR(255) NULL,
  `order_type` VARCHAR(50) NOT NULL DEFAULT 'order',
  `is_resource_addon` TINYINT(1) NOT NULL DEFAULT 0,
  `description` TEXT NULL,
  `breakdown` JSON NULL,
  `subscription_id` BIGINT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_number_unique` (`order_number`),
  KEY `idx_orders_user_id` (`user_id`),
  KEY `idx_orders_subscription_id` (`subscription_id`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_is_paid` (`is_paid`),
  KEY `idx_orders_is_active` (`is_active`),
  KEY `idx_orders_created_at` (`created_at`),
  KEY `idx_orders_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `orders` (`id`, `user_id`, `package_id`, `order_number`, `amount`, `subtotal`, `final_amount`, `status`, `is_paid`, `is_active`, `tracking_code`, `paid_at`, `coupon_code`, `discount_amount`, `module_ids`, `user_count`, `billing_period`, `package_name`, `order_type`, `is_resource_addon`, `description`, `breakdown`, `created_at`, `updated_at`, `deleted_at`, `subscription_id`) VALUES
(6, 6, NULL, 'ORD-20260914-9656', 12300000, 12300000, 12300000, 'completed', 1, 1, '4787120890', '2026-09-14 08:43:35', NULL, 0, '["account", "hr", "contacts", "mail", "crm", "project", "sale", "mass_mailing_sms"]', 1, 'yearly', 'اشتراک اختصاصی ابری (8 ماژول)', 'renewal', 0, NULL, NULL, '2026-09-14 08:43:32', '2026-09-14 08:43:35', NULL, 4),
(7, 1, NULL, 'ORD-20260916-1959', 12000000, 12000000, 12000000, 'completed', 1, 1, '4790376734', '2026-09-16 05:45:01', NULL, 0, '["account", "hr", "calendar", "contacts", "mail", "sale", "hr_attendance", "hr_recruitment", "hr_holidays", "crm", "activities", "survey"]', 1, 'yearly', 'اشتراک اختصاصی ابری (12 ماژول)', 'new', 0, NULL, NULL, '2026-09-16 05:45:00', '2026-09-16 05:45:01', NULL, NULL),
(8, 15, NULL, 'ORD-20260916-1802', 24000000, 24000000, 24000000, 'completed', 1, 1, '4790508555', '2026-09-16 07:38:45', NULL, 0, '["calendar", "contacts", "mail", "sale", "crm", "project", "hr", "hr_attendance", "survey", "im_livechat", "hr_holidays", "hr_recruitment", "activities", "stock", "survey_feedback", "loyalty", "knowledge", "helpdesk", "hr_payroll", "hr_timesheet", "ai_assistant", "account"]', 2, '6_months', 'اشتراک اختصاصی ابری (22 ماژول)', 'renewal', 0, NULL, NULL, '2026-09-16 07:38:37', '2026-09-16 07:38:45', NULL, 6),
(9, 1, NULL, 'ORD-20260916-2522', 7200000, 7200000, 7200000, 'completed', 1, 1, '4790515584', '2026-09-16 07:43:55', NULL, 0, '["account", "hr", "calendar", "contacts", "mail", "sale", "hr_attendance", "hr_recruitment", "hr_holidays", "crm", "activities", "survey"]', 1, '6_months', 'اشتراک اختصاصی ابری (12 ماژول)', 'new', 0, NULL, NULL, '2026-09-16 07:43:53', '2026-09-16 07:43:55', NULL, NULL);


-- -------------------------------------------------------------
-- 11. TRANSACTIONS TABLE (Payment Gateway Transactions)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` BIGINT UNSIGNED NOT NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `order_number` VARCHAR(100) NULL,
  `gateway` VARCHAR(50) NOT NULL DEFAULT 'zibal',
  `authority` VARCHAR(100) NULL,
  `reference_id` VARCHAR(100) NULL,
  `tracking_code` VARCHAR(100) NULL,
  `amount` BIGINT NOT NULL DEFAULT 0,
  `status` VARCHAR(50) NOT NULL DEFAULT 'initiated',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `raw_response` JSON NULL,
  `paid_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_transactions_order_id` (`order_id`),
  KEY `idx_transactions_user_id` (`user_id`),
  KEY `idx_transactions_reference_id` (`reference_id`),
  KEY `idx_transactions_tracking_code` (`tracking_code`),
  KEY `idx_transactions_status` (`status`),
  KEY `idx_transactions_is_active` (`is_active`),
  KEY `idx_transactions_created_at` (`created_at`),
  KEY `idx_transactions_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `transactions` (`id`, `order_id`, `user_id`, `order_number`, `gateway`, `authority`, `reference_id`, `tracking_code`, `amount`, `status`, `is_active`, `raw_response`, `paid_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(9, 6, 6, 'ORD-20260914-9656', 'zibal_sandbox', NULL, 'ZBL-1789375415-4692', '4787120890', 12300000, 'successful', 1, NULL, '2026-09-14 08:43:35', '2026-09-14 08:43:32', '2026-09-14 08:43:35', NULL),
(10, 7, 1, 'ORD-20260916-1959', 'zibal_sandbox', NULL, 'ZBL-1789537501-4566', '4790376734', 12000000, 'successful', 1, NULL, '2026-09-16 05:45:01', '2026-09-16 05:45:00', '2026-09-16 05:45:01', NULL),
(11, 8, 15, 'ORD-20260916-1802', 'zibal_sandbox', NULL, 'ZBL-1789544325-9125', '4790508555', 24000000, 'successful', 1, NULL, '2026-09-16 07:38:45', '2026-09-16 07:38:37', '2026-09-16 07:38:45', NULL),
(12, 9, 1, 'ORD-20260916-2522', 'zibal_sandbox', NULL, 'ZBL-1789544635-4576', '4790515584', 7200000, 'successful', 1, NULL, '2026-09-16 07:43:55', '2026-09-16 07:43:53', '2026-09-16 07:43:55', NULL);


-- -------------------------------------------------------------
-- 12. SUBSCRIPTIONS TABLE (Active ERP Cloud Subscriptions)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE `subscriptions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `package_id` BIGINT UNSIGNED NULL,
  `order_id` BIGINT UNSIGNED NULL,
  `title` VARCHAR(255) NULL,
  `package_name` VARCHAR(255) NULL,
  `plan_name` VARCHAR(191) NULL,
  `source` VARCHAR(30) NOT NULL DEFAULT 'purchase',
  `status` VARCHAR(50) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `billing_period` VARCHAR(50) NOT NULL DEFAULT 'monthly',
  `user_count` INT NOT NULL DEFAULT 1,
  `user_limit` INT NOT NULL DEFAULT 1,
  `usage_limit` INT NULL,
  `usage_used` INT NOT NULL DEFAULT 0,
  `price` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `total_price` DECIMAL(15,2) NOT NULL DEFAULT 0,
  `order_number` VARCHAR(100) NULL,
  `server_instance` TEXT NULL,
  `module_ids` JSON NULL,
  `starts_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_subscriptions_user_id` (`user_id`),
  KEY `idx_subscriptions_order_id` (`order_id`),
  KEY `idx_subscriptions_status` (`status`),
  KEY `idx_subscriptions_is_active` (`is_active`),
  KEY `idx_subscriptions_expires_at` (`expires_at`),
  KEY `idx_subscriptions_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `subscriptions` (`id`, `user_id`, `package_id`, `order_id`, `title`, `package_name`, `plan_name`, `source`, `status`, `is_active`, `billing_period`, `user_count`, `user_limit`, `usage_limit`, `usage_used`, `price`, `total_price`, `order_number`, `server_instance`, `module_ids`, `starts_at`, `expires_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(4, 6, NULL, 6, 'اشتراک اختصاصی ابری (8 ماژول)', 'اشتراک اختصاصی ابری (8 ماژول)', NULL, 'purchase', 'active', 1, 'yearly', 1, 1, NULL, 0, 12300000.00, 12300000.00, 'ORD-20260914-9656', '{"subdomain": "trial-6.karovita.ir", "portal_url": "/workspace/trial", "status": "online", "ssl": true, "database": "MySQL 8 Enterprise", "backup_status": "خودکار روزانه", "datacenter": "دیتاسنتر ابری تهران - آسیاتک"}', '["account", "hr", "contacts", "mail", "crm", "project", "sale", "mass_mailing_sms"]', '2026-09-14 08:42:28', '2027-09-19 08:42:28', '2026-09-14 08:42:28', '2026-09-14 08:43:35', NULL),
(5, 1, NULL, 7, 'اشتراک اختصاصی ابری (12 ماژول)', 'اشتراک اختصاصی ابری (12 ماژول)', NULL, 'purchase', 'cancelled', 0, 'yearly', 1, 1, NULL, 0, 12000000.00, 12000000.00, 'ORD-20260916-1959', '{"subdomain": "trial-1.karovita.ir", "portal_url": "/workspace/trial", "status": "online", "ssl": true, "database": "MySQL 8 Enterprise", "backup_status": "خودکار روزانه", "datacenter": "دیتاسنتر ابری تهران - آسیاتک"}', '["account", "hr", "calendar", "contacts", "mail", "sale", "hr_attendance", "hr_recruitment", "hr_holidays", "crm", "activities", "survey"]', '2026-09-16 05:44:55', '2027-09-21 05:44:55', '2026-09-16 05:44:55', '2026-09-16 06:13:37', NULL),
(6, 15, NULL, 8, 'اشتراک اختصاصی ابری (22 ماژول)', 'اشتراک اختصاصی ابری (22 ماژول)', NULL, 'purchase', 'active', 1, '6_months', 2, 2, NULL, 0, 24000000.00, 24000000.00, 'ORD-20260916-1802', '{"subdomain": "trial-15.karovita.ir", "portal_url": "/workspace/trial", "status": "online", "ssl": true, "database": "MySQL 8 Enterprise", "backup_status": "خودکار روزانه", "datacenter": "دیتاسنتر ابری تهران - آسیاتک"}', '["calendar", "contacts", "mail", "sale", "crm", "project", "hr", "hr_attendance", "survey", "im_livechat", "hr_holidays", "hr_recruitment", "activities", "stock", "survey_feedback", "loyalty", "knowledge", "helpdesk", "hr_payroll", "hr_timesheet", "ai_assistant", "account"]', '2026-09-16 07:18:34', '2027-03-20 07:18:34', '2026-09-16 07:18:34', '2026-09-16 07:38:45', NULL),
(7, 1, NULL, 9, 'اشتراک اختصاصی ابری (12 ماژول)', 'اشتراک اختصاصی ابری (12 ماژول)', NULL, 'purchase', 'active', 1, '6_months', 1, 1, NULL, 0, 7200000.00, 7200000.00, 'ORD-20260916-2522', '{"subdomain": "app-9.karovita.ir", "portal_url": "/workspace/9", "status": "online", "ssl": true, "database": "MySQL 8 Enterprise", "backup_status": "خودکار روزانه", "datacenter": "دیتاسنتر ابری تهران - آسیاتک"}', '["account", "hr", "calendar", "contacts", "mail", "sale", "hr_attendance", "hr_recruitment", "hr_holidays", "crm", "activities", "survey"]', '2026-09-16 07:43:55', '2027-03-15 07:43:55', '2026-09-16 07:43:55', '2026-09-16 07:43:55', NULL),
(8, 14, NULL, NULL, 'دوره آزمایشی 5 روزه کارویتا (22 ماژول)', 'دوره آزمایشی 5 روزه کارویتا (22 ماژول)', NULL, 'trial', 'active', 1, 'monthly', 1, 1, NULL, 0, 0.00, 0.00, 'TRL-20260916-1164', '{"subdomain": "trial-14.karovita.ir", "portal_url": "/workspace/trial", "status": "online", "ssl": true, "database": "MySQL 8 Enterprise", "backup_status": "خودکار روزانه", "datacenter": "دیتاسنتر ابری تهران - آسیاتک"}', '["sale", "activities", "contacts", "project", "calendar", "mail", "hr", "hr_attendance", "hr_holidays", "crm", "account", "ai_assistant", "hr_timesheet", "hr_payroll", "knowledge", "loyalty", "im_livechat", "helpdesk", "stock", "survey_feedback", "survey", "hr_recruitment"]', '2026-09-16 10:56:30', '2026-09-21 10:56:30', '2026-09-16 10:56:30', '2026-09-16 10:56:30', NULL);


-- -------------------------------------------------------------
-- 13. TICKETS TABLE (Support Tickets)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_number` VARCHAR(50) NOT NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `department_id` BIGINT UNSIGNED NULL,
  `department` VARCHAR(100) NULL,
  `service_name` VARCHAR(100) NULL,
  `package_name` VARCHAR(191) NULL,
  `assigned_to` BIGINT UNSIGNED NULL,
  `assigned_name` VARCHAR(100) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `title` VARCHAR(255) NULL,
  `priority` VARCHAR(20) NOT NULL DEFAULT 'medium',
  `status` VARCHAR(50) NOT NULL DEFAULT 'open',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_security_info` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_number_unique` (`ticket_number`),
  KEY `idx_tickets_user_id` (`user_id`),
  KEY `idx_tickets_department_id` (`department_id`),
  KEY `idx_tickets_assigned_to` (`assigned_to`),
  KEY `idx_tickets_status` (`status`),
  KEY `idx_tickets_is_active` (`is_active`),
  KEY `idx_tickets_created_at` (`created_at`),
  KEY `idx_tickets_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `tickets` (`id`, `ticket_number`, `user_id`, `department_id`, `department`, `service_name`, `package_name`, `assigned_to`, `assigned_name`, `subject`, `title`, `priority`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`, `is_security_info`) VALUES
(3, 'TKT-20260915-6392', 6, 1, 'technical', 'سرویس عمومی / سایر خدمات', 'سرویس عمومی / سایر خدمات', NULL, NULL, 'شسیشسی', 'شسیشسی', 'medium', 'closed', 1, '2026-09-15 11:19:02', '2026-09-15 14:27:25', NULL, 0),
(4, 'TKT-20260915-9462', 1, 1, 'technical', 'سرویس عمومی / بدون اشتراک فعال', 'سرویس عمومی / بدون اشتراک فعال', NULL, NULL, 'شسیشسی', 'شسیشسی', 'medium', 'closed', 1, '2026-09-15 11:20:04', '2026-09-15 14:27:55', NULL, 0),
(5, 'TKT-20260915-4848', 1, 1, 'technical', 'سرویس عمومی / بدون اشتراک فعال', 'سرویس عمومی / بدون اشتراک فعال', NULL, NULL, 'شسیشسی', 'شسیشسی', 'medium', 'closed', 1, '2026-09-15 11:20:52', '2026-09-15 14:27:12', NULL, 0),
(6, 'TKT-20260915-4615', 1, 1, 'technical', 'سرویس عمومی / بدون اشتراک فعال', 'سرویس عمومی / بدون اشتراک فعال', NULL, NULL, 'asd', 'asd', 'medium', 'closed', 1, '2026-09-15 13:33:54', '2026-09-15 14:27:19', NULL, 0),
(7, 'TKT-20260915-5226', 1, 1, 'technical', 'سرویس عمومی / بدون اشتراک فعال', 'سرویس عمومی / بدون اشتراک فعال', NULL, NULL, 'asd', 'asd', 'medium', 'closed', 1, '2026-09-15 13:35:23', '2026-09-15 13:46:51', NULL, 0),
(8, 'TKT-20260916-6760', 15, 2, 'پشتیبانی فنی', 'سرویس عمومی / سایر خدمات', 'سرویس عمومی / سایر خدمات', NULL, NULL, 'سلام', 'سلام', 'medium', 'closed', 1, '2026-09-16 07:31:47', '2026-09-16 07:33:39', NULL, 1);


-- -------------------------------------------------------------
-- 14. TICKET MESSAGES TABLE
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `ticket_messages`;
CREATE TABLE `ticket_messages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_id` BIGINT UNSIGNED NOT NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `sender_type` VARCHAR(50) NOT NULL DEFAULT 'user',
  `user_name` VARCHAR(100) NULL,
  `message` TEXT NOT NULL,
  `attachments` TEXT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'sent',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `is_security_info` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ticket_messages_ticket_id` (`ticket_id`),
  KEY `idx_ticket_messages_user_id` (`user_id`),
  KEY `idx_ticket_messages_status` (`status`),
  KEY `idx_ticket_messages_is_active` (`is_active`),
  KEY `idx_ticket_messages_created_at` (`created_at`),
  KEY `idx_ticket_messages_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `ticket_messages` (`id`, `ticket_id`, `user_id`, `sender_type`, `user_name`, `message`, `attachments`, `is_admin`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`, `is_security_info`) VALUES
(1, 1, 3, 'user', NULL, 'ضعیف', '[]', 0, 'sent', 1, '2026-09-15 11:17:38', '2026-09-15 11:17:38', NULL, 0),
(2, 2, 3, 'user', NULL, 'ضعیفففففففففف', '[]', 0, 'sent', 1, '2026-09-15 11:18:15', '2026-09-15 11:18:15', NULL, 0),
(3, 3, 6, 'user', NULL, 'شسیشسی', '[]', 0, 'sent', 1, '2026-09-15 11:19:02', '2026-09-15 11:19:02', NULL, 0),
(4, 4, 1, 'user', NULL, 'شسیشسی', '[]', 0, 'sent', 1, '2026-09-15 11:20:04', '2026-09-15 11:20:04', NULL, 0),
(5, 5, 1, 'user', NULL, 'شسیشسی', '[]', 0, 'sent', 1, '2026-09-15 11:20:52', '2026-09-15 11:20:52', NULL, 0),
(6, 6, 1, 'user', NULL, 'asd', '[]', 0, 'sent', 1, '2026-09-15 13:33:54', '2026-09-15 13:33:54', NULL, 0),
(7, 7, 1, 'user', NULL, 'asd', '[]', 0, 'sent', 1, '2026-09-15 13:35:23', '2026-09-15 13:35:23', NULL, 0),
(8, 8, 15, 'user', 'pourya ahmadi', 'سلام', '[{"file_name": "داده.png", "file_data": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABgAAAAQACAIAAACoEwUVAABVVGNhQlgAAFVUanVtYgAAAB5qdW1kYzJwYQARABCAAACqADibcQNjMnBhAAAAVS5qdW1iAAAAR2p1bWRjMm1hABEAEIAAAKoAOJtxA3VybjpjMnBhOjlhMzAzZTMwLWRkZWMtNGFmMS1iZmFjLTAyYWMwZTAwYzBmNAAAAAxXanVtYgAAAClqdW1kYzJhcwARABCAAACqADibcQNjMnBhLmFzc2VydGlvbnMAAAAJ0Wp1bWIAAAA7anVtZEDLDDK7ikidpwsq1vR/Q2kTYzJwYS5pY29uAAAAABhjMnNoR87uLu0r9CsWxH6wBOseLwAAABdiZmRiAGltYWdlL3N2Zyt4bWwAAAAJd2JpZGI8c3ZnIHdpZHRoPSI3MTYiIGhlaWdodD0iNzE2IiB2aWV3Qm94PSIwIDAgNzE2IDcxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTUwOC43NDkgMzE3LjM5OUM1MTYuNzc3IDI4Ny4zMTQgNTA4Ljk5MSAyNTMuODg0IDQ4NS4zODkgMjMwLjI4MkM0NjEuNzg4IDIwNi42ODEgNDI4LjM2IDE5OC44OTUgMzk4LjI3MyAyMDYuOTIzQzM3Ni4yMzEgMTg0LjkyOCAzNDMuMzkgMTc0Ljk1NiAzMTEuMTQ4IDE4My41OTZDMjc4LjkwNiAxOTIuMjM0IDI1NS40NSAyMTcuMjkyIDI0Ny4zNiAyNDcuMzYxQzIxNy4yOTEgMjU1LjQ1MSAxOTIuMjMzIDI3OC45MSAxODMuNTk1IDMxMS4xNDlDMTc0Ljk1NyAzNDMuMzkxIDE4NC45MjcgMzc2LjIzMiAyMDYuOTI0IDM5OC4yNzRDMTk4Ljg5NiA0MjguMzU5IDIwNi42ODMgNDYxLjc4OSAyMzAuMjg0IDQ4NS4zOTFDMjUzLjg4NSA1MDguOTkyIDI4Ny4zMTMgNTE2Ljc3OSAzMTcuNDAxIDUwOC43NUMzMzkuNDQyIDUzMC43NDUgMzcyLjI4NiA1NDAuNzE3IDQwNC41MjUgNTMyLjA3OUM0MzYuNzY3IDUyMy40NDEgNDYwLjIyMyA0OTguMzg0IDQ2OC4zMTMgNDY4LjMxNUM0OTguMzgzIDQ2MC4yMjQgNTIzLjQ0IDQzNi43NjYgNTMyLjA3OCA0MDQuNTI2QzU0MC43MTYgMzcyLjI4NSA1MzAuNzQ3IDMzOS40NDMgNTA4Ljc0OSAzMTcuNDAyVjMxNy4zOTlaTTQ3MC44OTkgMjQ0Ljc3NkM0ODYuODkyIDI2MC43NyA0OTMuNDg4IDI4Mi42MDEgNDkwLjY4NyAzMDMuNDEyTDQxNS41NzcgMjYwLjA0NkM0MTIuNDExIDI1OC4yMTggNDA4LjUwOSAyNTguMjE4IDQwNS4zNDUgMjYwLjA0NkwzMTcuNDAxIDMxMC44MlYyNzcuNTI2QzMxNy40MDEgMjc1LjE5MSAzMTguNjUyIDI3My4wMDUgMzIwLjY3NiAyNzEuODM3TDM4Ny42NDQgMjMzLjE3NEM0MTQuMTc4IDIxOC4zNTMgNDQ4LjM0NiAyMjIuMjIzIDQ3MC45MDEgMjQ0Ljc3Nkg0NzAuODk5Wk0zNTcuODM3IDMxMS4xNDRMMzk4LjI3NSAzMzQuNDkxVjM4MS4xODVMMzU3LjgzNyA0MDQuNTMyTDMxNy4zOTggMzgxLjE4NVYzMzQuNDkxTDM1Ny44MzcgMzExLjE0NFpNMjY0Ljc3NiAyNjkuNjkzQzI2NS4yMDcgMjM5LjMwNSAyODUuNjQ0IDIxMS42NDkgMzE2LjQ1MyAyMDMuMzkzQzMzOC4zIDE5Ny41NCAzNjAuNTA1IDIwMi43NDQgMzc3LjEyNyAyMTUuNTczTDMwMi4wMTQgMjU4LjkzN0MyOTguODQ4IDI2MC43NjQgMjk2Ljg5OCAyNjQuMTQ0IDI5Ni44OTggMjY3Ljc5OFYzNjkuMzQ2TDI2OC4wNjUgMzUyLjY5OUMyNjYuMDQzIDM1MS41MzEgMjY0Ljc3NiAzNDkuMzUzIDI2NC43NzYgMzQ3LjAxN1YyNjkuNjkxVjI2OS42OTNaTTIwMy4zOTEgMzE2LjQ1NEMyMDkuMjQ0IDI5NC42MDggMjI0Ljg1NCAyNzcuOTc4IDI0NC4yNzYgMjY5Ljk5OVYzNTYuNzNDMjQ0LjI3NiAzNjAuMzg0IDI0Ni4yMjYgMzYzLjc2MyAyNDkuMzkyIDM2NS41OTFMMzM3LjMzNyA0MTYuMzY1TDMwOC41MDMgNDMzLjAxM0MzMDYuNDgxIDQzNC4xODEgMzAzLjk2MSA0MzQuMTg4IDMwMS45MzkgNDMzLjAyTDIzNC45NzEgMzk0LjM1N0MyMDguODY4IDM3OC43ODkgMTk1LjEzOCAzNDcuMjYxIDIwMy4zOTEgMzE2LjQ1NFpNMjQ0Ljc3NSA0NzAuOUMyMjguNzgxIDQ1NC45MDYgMjIyLjE4NiA0MzMuMDc1IDIyNC45ODYgNDEyLjI2NEwzMDAuMDk2IDQ1NS42M0MzMDMuMjYzIDQ1Ny40NTcgMzA3LjE2NCA0NTcuNDU3IDMxMC4zMjggNDU1LjYzTDM5OC4yNzMgNDA0Ljg1NlY0MzguMTQ5QzM5OC4yNzMgNDQwLjQ4NSAzOTcuMDIyIDQ0Mi42NzEgMzk0Ljk5NyA0NDMuODM5TDMyOC4wMjkgNDgyLjUwMkMzMDEuNDk1IDQ5Ny4zMjIgMjY3LjMyNyA0OTMuNDUyIDI0NC43NzIgNDcwLjlIMjQ0Ljc3NVpNNDUwLjg5NyA0NDUuOTgyQzQ1MC40NjYgNDc2LjM3MSA0MzAuMDI5IDUwNC4wMjcgMzk5LjIyIDUxMi4yODNDMzc3LjM3MyA1MTguMTM2IDM1NS4xNjggNTEyLjkzMiAzMzguNTQ3IDUwMC4xMDJMNDEzLjY1OSA0NTYuNzM4QzQxNi44MjYgNDU0LjkxMSA0MTguNzc1IDQ1MS41MzIgNDE4Ljc3NSA0NDcuODc3VjM0Ni4zMjlMNDQ3LjYwOSAzNjIuOTc3QzQ0OS42MzEgMzY0LjE0NSA0NTAuODk3IDM2Ni4zMjMgNDUwLjg5NyAzNjguNjU5VjQ0NS45ODVWNDQ1Ljk4MlpNNTEyLjI4MiAzOTkuMjIxQzUwNi40MjkgNDIxLjA2OCA0OTAuODE5IDQzNy42OTcgNDcxLjM5NyA0NDUuNjc2VjM1OC45NDZDNDcxLjM5NyAzNTUuMjkyIDQ2OS40NDggMzUxLjkxMiA0NjYuMjgxIDM1MC4wODVMMzc4LjMzNiAyOTkuMzExTDQwNy4xNyAyODIuNjYzQzQwOS4xOTIgMjgxLjQ5NSA0MTEuNzEyIDI4MS40ODcgNDEzLjczNCAyODIuNjU1TDQ4MC43MDIgMzIxLjMxOEM1MDYuODA1IDMzNi44ODcgNTIwLjUzNiAzNjguNDE1IDUxMi4yODIgMzk5LjIyMVoiIGZpbGw9ImJsYWNrIi8+Cjwvc3ZnPgoAAAGSanVtYgAAAEFqdW1kY2JvcgARABCAAACqADibcRNjMnBhLmFjdGlvbnMudjIAAAAAGGMyc2jUZ33hffy1T4jjuME0iMXSAAABSWNib3KiZ2FjdGlvbnODpGZhY3Rpb25sYzJwYS5jcmVhdGVkZHdoZW7AdDIwMjYtMDktMTRUMDA6MDA6MDBabXNvZnR3YXJlQWdlbnSiZG5hbWVpZ3B0LWltYWdlZ3ZlcnNpb25jMi4wcWRpZ2l0YWxTb3VyY2VUeXBleEZodHRwOi8vY3YuaXB0Yy5vcmcvbmV3c2NvZGVzL2RpZ2l0YWxzb3VyY2V0eXBlL3RyYWluZWRBbGdvcml0aG1pY01lZGlhomZhY3Rpb25uYzJwYS5jb252ZXJ0ZWRkd2hlbsB0MjAyNi0wOS0xNFQwMDowMDowMFqiZmFjdGlvbngYYzJwYS53YXRlcm1hcmtlZC51bmJvdW5kZHdoZW7AdDIwMjYtMDktMTRUMDA6MDA6MDBacmFsbEFjdGlvbnNJbmNsdWRlZPQAAADDanVtYgAAAEBqdW1kY2JvcgARABCAAACqADibcRNjMnBhLmhhc2guZGF0YQAAAAAYYzJzaP5vjM5Aah5FkNjUdZTmgF8AAAB7Y2JvcqVqZXhjbHVzaW9uc4GiZXN0YXJ0GCFmbGVuZ3RoGVVgZG5hbWVuanVtYmYgbWFuaWZlc3RjYWxnZnNoYTI1NmRoYXNoWCAsLecKJJlfKnl+9mprk71XvXksfp/9UGbylxp0IgQAFGNwYWRIAAAAAAAAAAAAAAK6anVtYgAAACdqdW1kYzJjbAARABCAAACqADibcQNjMnBhLmNsYWltLnYyAAAAAotjYm9ypmppbnN0YW5jZUlEeCx4bXA6aWlkOjMxNGQzYmJmLTBlNjctNGZmZC1hOThiLWZlZjA2OTU1MjEwYXRjbGFpbV9nZW5lcmF0b3JfaW5mb6RkbmFtZXgYT3BlbkFJIE1lZGlhIFNlcnZpY2UgQVBJZGljb26iY3VybHgkc2VsZiNqdW1iZj1jMnBhLmFzc2VydGlvbnMvYzJwYS5pY29uZGhhc2hYIJQmQXiMz/NAn7o3gspyUKU3CSHJpKzZFi6fCGsc4M0Md29yZy5jb250ZW50YXV0aC5jMnBhX3JzZjAuNzkuMmtzcGVjVmVyc2lvbmUyLjIuMGlzaWduYXR1cmV4TXNlbGYjanVtYmY9L2MycGEvdXJuOmMycGE6OWEzMDNlMzAtZGRlYy00YWYxLWJmYWMtMDJhYzBlMDBjMGY0L2MycGEuc2lnbmF0dXJlcmNyZWF0ZWRfYXNzZXJ0aW9uc4OiY3VybHgkc2VsZiNqdW1iZj1jMnBhLmFzc2VydGlvbnMvYzJwYS5pY29uZGhhc2hYIJQmQXiMz/NAn7o3gspyUKU3CSHJpKzZFi6fCGsc4M0MomN1cmx4KnNlbGYjanVtYmY9YzJwYS5hc3NlcnRpb25zL2MycGEuYWN0aW9ucy52MmRoYXNoWCCOMmYrCgeOTdyGThl6Rhtqcz0MgbLduG18u7E5OqpXs6JjdXJseClzZWxmI2p1bWJmPWMycGEuYXNzZXJ0aW9ucy9jMnBhLmhhc2guZGF0YWRoYXNoWCBKhC4673RZwMFjRliLzy5WKLE2anxs12ztpSuR3o5jTWhkYzp0aXRsZWlpbWFnZS5wbmdjYWxnZnNoYTI1NgAARc5qdW1iAAAAKGp1bWRjMmNzABEAEIAAAKoAOJtxA2MycGEuc2lnbmF0dXJlAAAARZ5jYm9y0oRZB1WiASYYIYJZA3IwggNuMIIC86ADAgECAhRSlCUHgbVqhvkzF3hw1o6t72IaQTAKBggqhkjOPQQDAzCBpzELMAkGA1UEBhMCVVMxETAPBgNVBAgMCE5ldyBZb3JrMREwDwYDVQQHDAhOZXcgWW9yazETMBEGA1UECgwKVHJ1Zm8gSW5jLjEUMBIGA1UECwwLQ0EgRGl2aXNpb24xGjAYBgkqhkiG9w0BCQEWC2NhQHRydWZvLmFpMSswKQYDVQQDDCJUcnVmbyBDMlBBIENsYWltIFNpZ25pbmcgQ0EgKDIwMjUpMB4XDTI2MDMyMzAyNTMwMloXDTI3MDMyNDAyNTMwMlowRzELMAkGA1UEBhMCVVMxGTAXBgNVBAoMEE9wZW5BSSBPcENvLCBMTEMxHTAbBgNVBAMMFE9wZW5BSSBNZWRpYSBTZXJ2aWNlMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESqpE4gX/lrlPP8VsGeRutoYh53nozkzdKRVw+xuJZ8KNdAGRc/Mm9S9+4LWgcZYRYzNOJ1ZhjWl8ijimS/0qb6OCAVowggFWMB8GA1UdIwQYMBaAFMOzJJY0k6FZ6lIYa54X4Km61rBMMB0GA1UdDgQWBBQKd12L3lQTzn/zDzdxWsmHk1kx2DAMBgNVHRMBAf8EAjAAMA4GA1UdDwEB/wQEAwIGwDAfBgNVHSUEGDAWBgorBgEEAYPoXgIBBggrBgEFBQcDJDAlBgNVHSAEHjAcMAwGCisGAQQBg+heAQEwDAYKKwYBBAGD6DwBATBeBggrBgEFBQcBAQRSMFAwIQYIKwYBBQUHMAGGFWh0dHBzOi8vb2NzcC50cnVmby5haTArBggrBgEFBQcwAoYfaHR0cHM6Ly9jYS50cnVmby5haS9jMnBhLWNhLmNydDAzBgkrBgEEAYPoXgQEJgwkMDE5YmM0MDMtNWNkNy03NjY5LWFmZTYtZmRiMTcxNzdkNDI4MBkGCSsGAQQBg+heAwQMBgorBgEEAYPoXgMKMAoGCCqGSM49BAMDA2kAMGYCMQD/5oFiNWv70TfsT9gQvQqMqQ+mBNdWbS3qZxvVvolX750qrwd9eyqWWlGaoojvpc8CMQCtgDZrZ+hERAeVrM0BhL3tW8vdHVmLeIcDzg5lKxX7dJ+7xR2q0PF+uOzAiEt2FThZA9cwggPTMIIDWKADAgECAhQw6KHwpYlCa9K5gkhHmRncFjcCyzAKBggqhkjOPQQDAzCBqDELMAkGA1UEBhMCVVMxETAPBgNVBAgMCE5ldyBZb3JrMREwDwYDVQQHDAhOZXcgWW9yazETMBEGA1UECgwKVHJ1Zm8gSW5jLjEUMBIGA1UECwwLQ0EgRGl2aXNpb24xGjAYBgkqhkiG9w0BCQEWC2NhQHRydWZvLmFpMSwwKgYDVQQDDCNUcnVmbyBDMlBBIFJvb3QgQ0EgKDIwMjUsIEVDQyBQMzg0KTAeFw0yNjAyMDEwOTE1MThaFw0zMTAyMDIwOTE1MThaMIGnMQswCQYDVQQGEwJVUzERMA8GA1UECAwITmV3IFlvcmsxETAPBgNVBAcMCE5ldyBZb3JrMRMwEQYDVQQKDApUcnVmbyBJbmMuMRQwEgYDVQQLDAtDQSBEaXZpc2lvbjEaMBgGCSqGSIb3DQEJARYLY2FAdHJ1Zm8uYWkxKzApBgNVBAMMIlRydWZvIEMyUEEgQ2xhaW0gU2lnbmluZyBDQSAoMjAyNSkwdjAQBgcqhkjOPQIBBgUrgQQAIgNiAAT6nePm+iap9anW9g1vYcU48uYz6gX4CUK6t39puP/+hjrZp+dtJ/xCm6C8vvOu7I0CEplsz+LiuPpZ4dKhD9LrTR+MFpTlkk9Lx+fuvwrhuDUk4YFoGhEQNuEIGUfsqn6jggFAMIIBPDAdBgNVHQ4EFgQUw7MkljSToVnqUhhrnhfgqbrWsEwwHwYDVR0jBBgwFoAUA9Vfr36D5QQdWYAnSjT/Rf3rSXgwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwKQYDVR0lBCIwIAYKKwYBBAGD6F4CAQYIKwYBBQUHAyQGCCsGAQUFBwMEMEsGA1UdIAREMEIwDAYKKwYBBAGD6F4BATAyBgorBgEEAYPoPAEBMCQwIgYIKwYBBQUHAgEWFmh0dHBzOi8vdHJ1Zm8uYWkvY3BjcHMwXgYIKwYBBQUHAQEEUjBQMCEGCCsGAQUFBzABhhVodHRwczovL29jc3AudHJ1Zm8uYWkwKwYIKwYBBQUHMAKGH2h0dHBzOi8vY2EudHJ1Zm8uYWkvcm9vdC1jYS5jcnQwCgYIKoZIzj0EAwMDaQAwZgIxANUL/ipIu2RmAlZcGK/VHamYaH2+6PG4ur1AdDuswfgZPWOYLa6LB2X4geGqakrqZwIxAOtpNdTYxWmpTtGzLBYp1OCgrx77qUDJu5yH754Tq54tmfQ0BZRiuwuB6O0NuIz0tKNnc2lnVHN0MqFpdHN0VG9rZW5zgaFjdmFsWRSKMIIUhgYJKoZIhvcNAQcCoIIUdzCCFHMCAQExDzANBglghkgBZQMEAgEFADCBhgYLKoZIhvcNAQkQAQSgdwR1MHMCAQEGCisGAQQBg78wAQEwMTANBglghkgBZQMEAgEFAAQg2+5zZDhQFgAmN1LRuoDDtAaAwAd4P9lDFyg11KYvq0gCCEnQDjt2N00WGBYyMDI2MDkxNDA4NTIzOS45NzQ1MTlaMAOAAQECCEGnCWZZ8zdooIIQZjCCBPYwggNeoAMCAQICFGHbRigyioyNSga3v/5g4wJsP3G3MA0GCSqGSIb3DQEBCwUAMHsxCzAJBgNVBAYTAlVTMQswCQYDVQQIDAJDQTEWMBQGA1UEBwwNU2FuIEZyYW5jaXNjbzEZMBcGA1UECgwQT3BlbkFJIE9wQ28sIExMQzEMMAoGA1UECwwDVFNBMR4wHAYDVQQDDBVPcGVuQUkgVFNBIElzc3VpbmcgQ0EwHhcNMjYwNDA4MTc0NjI2WhcNMzcwNzA5MTc0NjI2WjB1MQswCQYDVQQGEwJVUzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBGcmFuY2lzY28xGTAXBgNVBAoMEE9wZW5BSSBPcENvLCBMTEMxDDAKBgNVBAsMA1RTQTEYMBYGA1UEAwwPT3BlbkFJIFRTQSBMZWFmMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA6srFrZT98P0nn8d4p2EEyv8OKWEq+6GIzV+oopedDokvi5HIH7ywlpA9CBxVgsGWjjZqFa2JaeiQ2yxEMoOoCs135TXo7qhkW/644I6d5wIgoSjDNd2nEDfpIvcJTZeatIRzwC58qVBHKKC08Gkf8LCHKXpZ/g8UFDVC+dlpUhdKIDfyaMwP8S23gpYgG0sRDkYSXD2kFIa4S0VmOKJOTSfKlbp1DMxOh2qfdMMgFQUBJF8NxH5crv4d8x8Lle0Akd889YabKhJeDtYPHNDdyfoNyE3DyYRaGEks5DhzGmBSuEzuxvO3ttjdaqnOILpd1sRcNRBk8gMjEVM/Yo5lBRFdcCvUyWsJgUVS6BpX7VpGXdpddpwleRBog1GkmIR1kXKYVf/Y40Nise1pZydBvMWP8moHK4NJ6OEtGDQOuzkHr2e9tJUeyAKyvUVnzXIBiJRfVUsGLK2v7aX0JK93Az6DimRRj5GMDDmWS7A9rvoEmaE+GIw98L4XNqEu9WO1AgMBAAGjeDB2MAwGA1UdEwEB/wQCMAAwDgYDVR0PAQH/BAQDAgbAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMB0GA1UdDgQWBBSkJ1SCooqAez3Fhs0/cNnCg5lReDAfBgNVHSMEGDAWgBTyFPCwxxdUPSNDhdzKc9BygD24qDANBgkqhkiG9w0BAQsFAAOCAYEAIPskT0HAwLyYsjISIBCNIJlINRJPxEZWfqc+P7alI/kqSD7gUZ0fRUB4wbuDTpNQyZsnlmjfTc7y9hzSeavv6sEf2j/1mFkI5nDNifTuR4uqy+z/jH4U4UbYkeacuB7kNEb/YdJ4+H04OeNS7RtfZuhzwAByO+Soq46GGyqjNyH5O997XFTYTMdqKkt/z0N0YAWAc6PJ0Xevh6n9tbGEam6/iCrOmqGaq6KegkgHDDfFAmNRl9tSfG8eZ8lpCELVz/X7rRtei5Di4Ah5PC4bE4NqnqXoJUGPhRAB7eQYwaA6jf6dUlAa74fe4WTNVfkhIN+2Ke+fJ27RujRGq0oiT+diFXfdRSPdYS3CMSmPxLl+eQIGq7RX1MHszx0G4Vx7ZUmwGetNq6THJ0BOprS1j898w7RDp3bTXjBj7qgXrjUodGSrWjXjWy86Pk4KYdYwTUOb/04uxiG5PjosIBlXMHVqjmRLotAJ0RbXoGcmQW1n+ANwdrglJlb5kSYnw0tJMIIFfjCCA2agAwIBAgIUBI0EysbFC8XaGbC88U4RlaXqvBkwDQYJKoZIhvcNAQELBQAweDELMAkGA1UEBhMCVVMxCzAJBgNVBAgMAkNBMRYwFAYDVQQHDA1TYW4gRnJhbmNpc2NvMRkwFwYDVQQKDBBPcGVuQUkgT3BDbywgTExDMQwwCgYDVQQLDANUU0ExGzAZBgNVBAMMEk9wZW5BSSBUU0EgUm9vdCBDQTAgFw0yNjA0MDgxNzQ2MjZaGA8yMTI2MDQwOTE3NDYyNlowezELMAkGA1UEBhMCVVMxCzAJBgNVBAgMAkNBMRYwFAYDVQQHDA1TYW4gRnJhbmNpc2NvMRkwFwYDVQQKDBBPcGVuQUkgT3BDbywgTExDMQwwCgYDVQQLDANUU0ExHjAcBgNVBAMMFU9wZW5BSSBUU0EgSXNzdWluZyBDQTCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAIm81LniyKELvmG73jxkZn6nvpxtENOpMAcmPAT04GsgOd+VNO2pomUISNs3hjKDjswKSqDA8zRsoMCYzSufpfTLfNkPJt5+yU2i72Nbkeb2WajSAfpO+dk4K1oOzWBamIGYqNdTxuMZ1i5IrENXCemU8kf5bEWKFWC3964vXqI1ToU4hWmfNJ3QTdhDPc00bfxjk/zTcLtK6Hboak5mSaDt/PgYvu+aF7eod6zvtzjMudQqM8R2D9ZAEXfL/sddFy1A096LPMAY1kAUQZnLlD8sfQBrUvyeylC3CUdFFeEFI1X6sU9vVJiV9H26+GjhIhx63IqRQ4sVti4SQ7FiHKC+yiSOLu+/pNFN6Lg/Mc8mPcUAUOry2SQgZO3Vc54ucHiq3lY8BfnUgKLora/2+6ijXMtoq0TbMHfyxDR0a1Vtxof78jI8nnEORRP37FAP+/7WBDEmu9DETWHiQtuvwytuXysZG+bisO+NXETNH8BzfY+i6b1tgrwlZYQIMGntFQIDAQABo3sweTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjATBgNVHSUEDDAKBggrBgEFBQcDCDAdBgNVHQ4EFgQU8hTwsMcXVD0jQ4XcynPQcoA9uKgwHwYDVR0jBBgwFoAUWMJAoDxHdiuo5m6okZaOlsi32eQwDQYJKoZIhvcNAQELBQADggIBAJLsN1zebOtk2q6hEQkwcq7ccgj1O7wPej3WxuEv9oMzfegfV0AYTkyZqmvUmdkUi9tr1kz4ytBZM9OhoDhcI4hEJPuH4faTBie8oe1MX2dd/zWrMdLsexHUQEM3T8KEG5y6ZMgPsKIdfpo2+OHQgrNQQ7LgVb2AlMhZUk5KdN5dx0VYm7f6MKo73Ee81S4suTgYYyx5WrfdVa09Qt+IA8/xaP5zANRat94kApeRwOdn/tymCvOlRhGzURx/Es+Nr1/jGMi4QMa94/nWS3HQZF3lZMJLwF530T3HW54Vz3v9lJTnAUsIUdr7ZPSrEfA1lPH2vn4rDt2ymj1Q3VDDlmSObasMc58oBjsEd9CX7W9FT7EzLl9G64O2qWEfvNeCrviAb8LjaRUw5m18OkSSKwaYLa/cNMG+pSpI54fI3jgMtQQMM8rjhFBw8bIeS96NT/aRGdxfhfrx5tHXyqfutJ/2IXgpgfDjcFh3ARCGpDpLl4NG6NrCanbJqRLLIRwPRb5lsaCGLoC8WUtNm0MfbbTXhOD88NXIYZANQ44Tap3D8SE8hF0G/jvW2CM5RQtfHXEN+jL9oICVRLVPAOXDdP3iTodyhvTwUQGHHgi91LUrNWwGEJKkO2tqnbr9wDsHnHbCDNUYOX9J2uOUHD5QCGrXTOKJYZ3v68/Fw0BucHo4MIIF5jCCA86gAwIBAgIUE1A7bImM8CQDMyyP90+O+32C7BswDQYJKoZIhvcNAQELBQAweDELMAkGA1UEBhMCVVMxCzAJBgNVBAgMAkNBMRYwFAYDVQQHDA1TYW4gRnJhbmNpc2NvMRkwFwYDVQQKDBBPcGVuQUkgT3BDbywgTExDMQwwCgYDVQQLDANUU0ExGzAZBgNVBAMMEk9wZW5BSSBUU0EgUm9vdCBDQTAgFw0yNjA0MDgxNzQ2MjVaGA8yMTI2MDQwOTE3NDYyNVoweDELMAkGA1UEBhMCVVMxCzAJBgNVBAgMAkNBMRYwFAYDVQQHDA1TYW4gRnJhbmNpc2NvMRkwFwYDVQQKDBBPcGVuQUkgT3BDbywgTExDMQwwCgYDVQQLDANUU0ExGzAZBgNVBAMMEk9wZW5BSSBUU0EgUm9vdCBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAPaS6dIUuq2e4RqsdahWG9iqsbNqkl+WefWStxQtJPi/wBqvYL7Bms15mtxsmv42msGYFqQ/5CyduqWlUHOzCsL5GvPESS94vdLsvOc/9JvRGg/yoGGiLIklylEGERf5JRCc0sYv9InEQRIO/iYe0201zey7NWBAqIVRvvbukJjxKtidehBratku2WPz5RRcKcWGIsGKHGjN6zieqVCWWyND+zj/Qnw7OqFRLyXJSNwx/1By7vB8oXfNGG+BYfM/v27o0huxpgg25Gsy+/53qF6bXN3dMZBMjmX/FoHLQc4oMVPKGEPOSARufdZkFrMpEOS0Ljq3VFpyVlfzqGp9Hu/mYR/dZcgOSAlJmTJ08AqizN2TAFOsI72ChSCx777tHaF3AO46RjOinuyv6QYxZrRmb7KJk6B+lQ4PIc5B+F7wjunNucDVM1140NAnMc9QMHJzHR7aasLAk8+t3A9kh/b7CE6IdvU+7//+SLJl3Lgv2BtyYtp0JAzr99BoJx49fWul+SA0JK7UeioMbBPJbFTwsEAOvkaKdQbdSaNENERoZv7DA2k9gve4pqu2HjXFcKIyNiKMlFGNF2AX8e2GPbEZUOxhcybCCr4PIsSM/HJ8aW+6i11S1KlOuu4XbpvqXnuyEiXLzekDJFraFWEdb8SRhOaJM3tjGqCLynr9bTCzLAgMBAAGjZjBkMBIGA1UdEwEB/wQIMAYBAf8CAQEwDgYDVR0PAQH/BAQDAgEGMB0GA1UdDgQWBBRYwkCgPEd2K6jmbqiRlo6WyLfZ5DAfBgNVHSMEGDAWgBRYwkCgPEd2K6jmbqiRlo6WyLfZ5DANBgkqhkiG9w0BAQsFAAOCAgEAWPiBkQyY8mxh/siGHdZbhB2m1r64pl0MXUnLuKEpzS2duFj58ISJPTz4b9VqH7QqolWS8GeBmV61VAz7mkaA4wJRAFPADgPBiFfe74JVfuP0fRjrDyb8g/8hqMGs3tsbk6sZzdAwdhg6k53OqmcDDTkaLoB0323wfhN2L+nqUEGLOD1s5eA+7i/bZFQ2XhG+YkW20SG0gDyMGOvanNZKqdVUZVtr0Vh+wEmH6+tLX5IMO5TXmob2oVnOR/A4rMOwfwN0ZNHAUjuhsXsoa+EOaZf4AhgMKBc7J/+upBCe92XLoPTqub2UzkTimLEKSGjuVakhpWCP/srWfdF7hiCcDvOoeNDG2kAuyIEFC1xiqCrB+1bnGHkHjhGv7OXb03D+RsxjqGTxPOmvpWS8Xr+FCC0esM7judOkEddSu3CLhp37Lr8K9tJVKyNCK0Nc7KGCYT/Pce2w95fp5MvCPPysd7e23CDBTOmJsg+yL3/DfpJknAi1hN7Mlv2JsEu1Q33S6a2G/RnZLZ+9AO7AtEdWI3xIFZEOTg9niSB7YgjByV5V8fYGxlEjV2/vh74UIEZ5vpQCscggKJ2ViogmVQVmUu8Yf9lLuqhaFOnCLK2fC8NcQvOh9SdkeXGMClqe/bn5RXkHcB7hagO1N5aOWP1Fv1QljIMDPQ/ZJjMj0Fh3prgxggNoMIIDZAIBATCBkzB7MQswCQYDVQQGEwJVUzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBGcmFuY2lzY28xGTAXBgNVBAoMEE9wZW5BSSBPcENvLCBMTEMxDDAKBgNVBAsMA1RTQTEeMBwGA1UEAwwVT3BlbkFJIFRTQSBJc3N1aW5nIENBAhRh20YoMoqMjUoGt7//+YOMCbD9xtzANBglghkgBZQMEAgEFAKCCASUwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAbaNdmxin6Mnazk+gcuMAywGv16SPa6mCPMOXPGT9AsTCB1QYLKoZIhvcNAQkQAi8xgcUwgcIwgb8wgbwEIL1PubKQTIE2Z4hu70Hhbf4E2SIHnb9bkkrQosRgRiJ6MIGXMH+kfTB7MQswCQYDVQQGEwJVUzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBGcmFuY2lzY28xGTAXBgNVBAoMEE9wZW5BSSBPcENvLCBMTEMxDDAKBgNVBAsMA1RTQTEeMBwGA1UEAwwVT3BlbkFJIFRTQSBJc3N1aW5nIENBAhRh20YoMoqMjUoGt7//+YOMCbD9xtzANBgkqhkiG9w0BAQsFAASCAYDnq4oLdXcrHkUvLiBYaemeYPtABjYvXXAsRMlqimYC23Vzw8tTbw2qfqNdZAkz5Qy7sA9Xakaza/pT/44hm01+eIJhP4ouNgyB/H2VtN0LJ/TjvdYDnPfDifLriitM+B/UaB5waLgdb+6nHJy0o3FTfzfg4VUQAzY72n3YgMP7ecpPi6m06NQCIiWCaoKKHwyyTkFVGmvGIWI5q1OF1j9fIymbuK6M2wSVdGZLGR0vflOiGCyrtkyzBaUrYoPjxMQDR8gMkTscR7KtfOYK9n6cxuEY2ZF8Skwbke5W09O1amlZztX2HhAbXql6EUt0DsSMOhjeT7JjRyRfLRK+dXek5MRpm4OyFjD8tQ/pbdL7y6FjR+Byw5EupU3Mev+66bEbTiHlB/kxFJvGLv0Aq9ceRuhvw37LlUVUh+7FZuhOm32LLmj3wK5PYKngykPrTfqns1iS+epPLNJ+Q9H8RmE1imtGBltXlnU8NFHplns0a4cMIlVvl3K3XuHd5uIjqphlclZhbHOhaG9jc3BWYWxzgVkEHDCCBBgKAQCgggQRMIIEDQYJKwYBBQUHMAEBBIID/jCCA/owgaKiFgQU3WfsVXnXozR073kot5cHeYpGQ/UYDzIwMjYwOTExMjIwMzE1WjB3MHUwTTAJBgUrDgMCGgUABBQ+THyOUAuHbHMVvq9ul+oQ7pQgyQQUw7MkljSToVnqUhhrnhfgqbrWsEwCFFKUJQeBtWqG+TMXeHDWjq3vYhpBgAAYDzIwMjYwOTExMjIwMzE1WqARGA8yMDI2MDkxODIyMDMxNVowCgYIKoZIzj0EAwIDSQAwRgIhAONuTcgowkTVyRekB5jsGlUUbj/mGtznMeDTELynUspFAiEAhEr4/UsZtZZt43FPKYtngJKJhw8zAEcEiTDt8Mz5st2gggL6MIIC9jCCAvIwggJ3oAMCAQICFCa44Y6LbgtXR48qU2CRaPXRFnw8MAoGCCqGSM49BAMDMIGnMQswCQYDVQQGEwJVUzERMA8GA1UECAwITmV3IFlvcmsxETAPBgNVBAcMCE5ldyBZb3JrMRMwEQYDVQQKDApUcnVmbyBJbmMuMRQwEgYDVQQLDAtDQSBEaXZpc2lvbjEaMBgGCSqGSIb3DQEJARYLY2FAdHJ1Zm8uYWkxKzApBgNVBAMMIlRydWZvIEMyUEEgQ2xhaW0gU2lnbmluZyBDQSAoMjAyNSkwHhcNMjYwODA5MDA0NjE1WhcNMjYxMTA3MDA0NjE1WjCBnjELMAkGA1UEBhMCVVMxETAPBgNVBAgMCE5ldyBZb3JrMREwDwYDVQQHDAhOZXcgWW9yazETMBEGA1UECgwKVHJ1Zm8gSW5jLjEUMBIGA1UECwwLQ0EgRGl2aXNpb24xGjAYBgkqhkiG9w0BCQEWC2NhQHRydWZvLmFpMSIwIAYDVQQDDBlUcnVmbyBDMlBBIE9DU1AgUmVzcG9uZGVyMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEtMaz1BjMWyAyIk9qw9P2mxju6Jigy7z21liXZ9FtTMBpyMhw5F8Gf6y0K3NUg5kNStINEunS/znXDFwGtnSzMKOBhzCBhDAdBgNVHQ4EFgQU3WfsVXnXozR073kot5cHeYpGQ/UwHwYDVR0jBBgwFoAUw7MkljSToVnqUhhrnhfgqbrWsEwwDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwkwDwYJKwYBBQUHMAEFBAIFADAKBggqhkjOPQQDAwNpADBmAjEAyj/AgEPA/gTE3AiyTFLbGn2gNyBdeSXUT606pIdhc9qYAx0kVognYnPby45pEC/WAjEAkU3SyqZ3HfllSGbzu2HfhW2YlthaWOeud0ET+HV0R/Cy5oi07j9RIM99miLwHPJg", "file_type": "image/png"}]', 0, 'sent', 1, '2026-09-16 07:31:47', '2026-09-16 07:31:47', NULL, 1),
(9, 8, 15, 'user', 'pourya ahmadi', 'درود', '[]', 0, 'sent', 1, '2026-09-16 07:32:53', '2026-09-16 07:32:53', NULL, 0);


-- -------------------------------------------------------------
-- 15. TICKET ATTACHMENTS TABLE
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `ticket_attachments`;
CREATE TABLE `ticket_attachments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_id` BIGINT UNSIGNED NOT NULL,
  `message_id` BIGINT UNSIGNED NULL,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_data` LONGTEXT NOT NULL,
  `file_type` VARCHAR(100) NOT NULL,
  `file_size` BIGINT NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ticket_attachments_ticket_id` (`ticket_id`),
  KEY `idx_ticket_attachments_message_id` (`message_id`),
  KEY `idx_ticket_attachments_user_id` (`user_id`),
  KEY `idx_ticket_attachments_status` (`status`),
  KEY `idx_ticket_attachments_is_active` (`is_active`),
  KEY `idx_ticket_attachments_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- 16. GATEWAY SETTINGS TABLE (Payment & SMS Configuration)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `gateway_settings`;
CREATE TABLE `gateway_settings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `zibal_merchant` VARCHAR(100) NOT NULL DEFAULT '',
  `zibal_sandbox` TINYINT(1) NOT NULL DEFAULT 0,
  `zibal_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `sms_provider` VARCHAR(50) NOT NULL DEFAULT 'sms_ir',
  `sms_api_key` VARCHAR(255) NULL,
  `sms_line_number` VARCHAR(50) NULL,
  `sms_template_otp` VARCHAR(50) NULL,
  `sms_param_name` VARCHAR(50) NOT NULL DEFAULT 'CODE',
  `sms_templates_json` JSON NULL,
  `sms_sandbox` TINYINT(1) NOT NULL DEFAULT 0,
  `sms_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gateway_settings_status` (`status`),
  KEY `idx_gateway_settings_is_active` (`is_active`),
  KEY `idx_gateway_settings_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gateway_settings` (`id`, `zibal_merchant`, `zibal_sandbox`, `zibal_enabled`, `sms_provider`, `sms_api_key`, `sms_line_number`, `sms_template_otp`, `sms_param_name`, `sms_templates_json`, `sms_sandbox`, `sms_enabled`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '6a5f37d32884aa3809632821', 0, 1, 'sms_ir', 'ocv39CACg6Vg3cg3DbY3mUwfOti7dktYUwksl3jA3Jt1qI0z', '30007732', '418155', 'CODE', '{"otp":418155,"invoice_issued":418155,"sub_expiring_7days":418157,"sub_expiring_3days":418158,"ticket_created":418159,"payment_success":418155}', 0, 1, 'active', 1, '2026-09-10 06:10:08', '2026-09-19 12:00:00', NULL)
ON DUPLICATE KEY UPDATE
  `zibal_merchant` = VALUES(`zibal_merchant`),
  `zibal_sandbox` = VALUES(`zibal_sandbox`),
  `zibal_enabled` = VALUES(`zibal_enabled`),
  `sms_provider` = VALUES(`sms_provider`),
  `sms_api_key` = VALUES(`sms_api_key`),
  `sms_line_number` = VALUES(`sms_line_number`),
  `sms_template_otp` = VALUES(`sms_template_otp`),
  `sms_param_name` = VALUES(`sms_param_name`),
  `sms_templates_json` = VALUES(`sms_templates_json`),
  `sms_sandbox` = VALUES(`sms_sandbox`),
  `sms_enabled` = VALUES(`sms_enabled`),
  `updated_at` = VALUES(`updated_at`);

-- -------------------------------------------------------------
-- 17. SMS LOGS TABLE (SMS Dispatch History & Status)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `sms_logs`;
CREATE TABLE `sms_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `mobile` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `template_id` VARCHAR(50) NULL,
  `event_type` VARCHAR(50) NULL,
  `response_data` TEXT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'sent',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sms_logs_mobile` (`mobile`),
  KEY `idx_sms_logs_status` (`status`),
  KEY `idx_sms_logs_is_active` (`is_active`),
  KEY `idx_sms_logs_created_at` (`created_at`),
  KEY `idx_sms_logs_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `sms_logs` (`id`, `mobile`, `message`, `template_id`, `event_type`, `response_data`, `status`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=16157', '418155', NULL, '{"data": {"messageId": 711774594, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-10 06:10:25', '2026-09-10 06:10:25', NULL),
(2, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=81861', '418155', NULL, '{"data": {"messageId": 711790089, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-10 06:13:38', '2026-09-10 06:13:38', NULL),
(3, '09109960142', 'ارسال پیامک با الگو (قالب 418155): CODE=98719', '418155', NULL, '{"data": {"messageId": 715792918, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-13 08:26:22', '2026-09-13 08:26:22', NULL),
(4, '09109960142', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260913-4644', '418155', NULL, '{"data": {"messageId": 715811435, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-13 08:31:57', '2026-09-13 08:31:57', NULL),
(5, '09352913139', 'ارسال پیامک با الگو (قالب 418155): CODE=16880', '418155', NULL, '{"data": {"messageId": 716340908, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-13 12:04:08', '2026-09-13 12:04:08', NULL),
(6, '09112100142', 'ارسال پیامک با الگو (قالب 418155): CODE=62257', '418155', NULL, '{"data": {"messageId": 717502018, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 04:47:10', '2026-09-14 04:47:10', NULL),
(7, '09112100142', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260914-7852', '418155', NULL, '{"data": {"messageId": 717502563, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 04:48:53', '2026-09-14 04:48:53', NULL),
(8, '09113137018', 'ارسال پیامک با الگو (قالب 418155): CODE=49078', '418155', NULL, '{"data": {"messageId": 717525518, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 05:20:13', '2026-09-14 05:20:13', NULL),
(9, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=88443', '418155', NULL, '{"data": {"messageId": 717604176, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 05:50:22', '2026-09-14 05:50:22', NULL),
(10, '09113137018', 'ارسال پیامک با الگو (قالب 418155): CODE=36890', '418155', NULL, '{"data": {"messageId": 717605536, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 05:53:40', '2026-09-14 05:53:40', NULL),
(11, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=13342', '418155', NULL, '{"data": {"messageId": 717837076, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 08:39:42', '2026-09-14 08:39:42', NULL),
(12, '09113175211', 'ارسال پیامک با الگو (قالب 418155): CODE=70006', '418155', NULL, '{"data": {"messageId": 717837630, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 08:40:16', '2026-09-14 08:40:16', NULL),
(13, '09113175211', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260914-9656', '418155', NULL, '{"data": {"messageId": 717847098, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-14 08:43:35', '2026-09-14 08:43:35', NULL),
(14, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=12323', '418155', NULL, '{"data": {"messageId": 720058326, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 10:42:58', '2026-09-15 10:42:58', NULL),
(15, '09210895901', 'ارسال پیامک با الگو (قالب 418155): CODE=17223', '418155', NULL, '{"data": {"messageId": 720058901, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 10:43:46', '2026-09-15 10:43:46', NULL),
(16, '09109960142', 'ارسال پیامک با الگو (قالب 418155): CODE=97729', '418155', NULL, '{"data": {"messageId": 720130361, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 11:16:21', '2026-09-15 11:16:21', NULL),
(17, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=19693', '418155', NULL, '{"data": {"messageId": 720133193, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 11:19:34', '2026-09-15 11:19:34', NULL),
(18, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=20725', '418155', NULL, '{"data": {"messageId": 720178372, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 11:56:01', '2026-09-15 11:56:01', NULL),
(19, '09114995930', 'ارسال پیامک با الگو (قالب 418155): CODE=96515', '418155', NULL, '{"data": {"messageId": 720232567, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 12:23:55', '2026-09-15 12:23:55', NULL),
(20, '09012207286', 'ارسال پیامک با الگو (قالب 418155): CODE=77571', '418155', NULL, '"Operation timed out after 12002 milliseconds with 0 bytes received"', 'failed', 1, '2026-09-15 12:24:51', '2026-09-15 12:24:51', NULL),
(21, '09114995930', 'ارسال پیامک با الگو (قالب 418155): CODE=90873', '418155', NULL, '{"data": {"messageId": 720245817, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 12:29:13', '2026-09-15 12:29:13', NULL),
(22, '09113162780', 'ارسال پیامک با الگو (قالب 418155): CODE=99818', '418155', NULL, '{"data": {"messageId": 720291137, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 13:19:33', '2026-09-15 13:19:33', NULL),
(23, '09117114163', 'ارسال پیامک با الگو (قالب 418155): CODE=26307', '418155', NULL, '{"data": {"messageId": 720291973, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 13:21:49', '2026-09-15 13:21:49', NULL),
(24, '09113162780', 'ارسال پیامک با الگو (قالب 418155): CODE=60963', '418155', NULL, '{"data": {"messageId": 720637381, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-15 19:36:07', '2026-09-15 19:36:07', NULL),
(25, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260916-1959', '418155', NULL, '{"data": {"messageId": 720887482, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 05:45:02', '2026-09-16 05:45:02', NULL),
(26, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=83392', '418155', NULL, '{"data": {"messageId": 720914889, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 06:09:00', '2026-09-16 06:09:00', NULL),
(27, '09339945047', 'ارسال پیامک با الگو (قالب 418155): CODE=57048', '418155', NULL, '{"data": {"messageId": 720916502, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 06:13:50', '2026-09-16 06:13:50', NULL),
(28, '09339945047', 'ارسال پیامک با الگو (قالب 418155): CODE=80588', '418155', NULL, '{"data": {"messageId": 720946479, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 06:29:20', '2026-09-16 06:29:20', NULL),
(29, '09114995930', 'ارسال پیامک با الگو (قالب 418155): CODE=37948', '418155', NULL, '{"data": {"messageId": 720990772, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 07:00:31', '2026-09-16 07:00:31', NULL),
(30, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=25347', '418155', NULL, '{"data": {"messageId": 720994251, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 07:06:21', '2026-09-16 07:06:21', NULL),
(31, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260916-1802', '418155', NULL, '{"data": {"messageId": 721023561, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 07:38:45', '2026-09-16 07:38:45', NULL),
(32, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=13791', '418155', NULL, '{"data": {"messageId": 721032884, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 07:43:34', '2026-09-16 07:43:34', NULL),
(33, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=ORD-20260916-2522', '418155', NULL, '{"data": {"messageId": 721025792, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 07:43:55', '2026-09-16 07:43:55', NULL),
(34, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=47609', '418155', NULL, '{"data": {"messageId": 721057543, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 08:08:42', '2026-09-16 08:08:42', NULL),
(35, '09128066062', 'ارسال پیامک با الگو (قالب 418155): CODE=27894', '418155', NULL, '{"data": {"messageId": 721058290, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 08:09:59', '2026-09-16 08:09:59', NULL),
(36, '09339945047', 'ارسال پیامک با الگو (قالب 418155): CODE=45254', '418155', NULL, '{"data": {"messageId": 721153827, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 08:56:49', '2026-09-16 08:56:49', NULL),
(37, '09111273476', 'ارسال پیامک با الگو (قالب 418155): CODE=62061', '418155', NULL, '{"data": {"messageId": 721167697, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 09:12:36', '2026-09-16 09:12:36', NULL),
(38, '09114995930', 'ارسال پیامک با الگو (قالب 418155): CODE=39540', '418155', NULL, '{"data": {"messageId": 721301647, "cost": 1}, "status": 1, "message": "موفق"}', 'sent', 1, '2026-09-16 11:01:41', '2026-09-16 11:01:41', NULL);


-- -------------------------------------------------------------
-- 18. AUDIT LOGS TABLE (Security & Configuration Auditing)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `user_name` VARCHAR(191) NOT NULL DEFAULT 'System',
  `user_mobile` VARCHAR(50) NULL,
  `user_role` VARCHAR(50) NOT NULL DEFAULT 'user',
  `action_type` VARCHAR(100) NOT NULL,
  `action_description` TEXT NOT NULL,
  `resource_type` VARCHAR(100) NULL,
  `resource_id` VARCHAR(100) NULL,
  `ip_address` VARCHAR(100) NULL,
  `user_agent` TEXT NULL,
  `details` JSON NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'SUCCESS',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_user_id` (`user_id`),
  KEY `idx_audit_logs_action_type` (`action_type`),
  KEY `idx_audit_logs_status` (`status`),
  KEY `idx_audit_logs_is_active` (`is_active`),
  KEY `idx_audit_logs_created_at` (`created_at`),
  KEY `idx_audit_logs_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed initial admin audit entry
INSERT INTO `audit_logs` (`id`, `user_id`, `user_name`, `user_mobile`, `user_role`, `action_type`, `action_description`, `resource_type`, `resource_id`, `ip_address`, `user_agent`, `status`, `is_active`, `created_at`) VALUES
(1, 1, 'اردلان داوودی (مدیر ارشد)', '09111273476', 'admin', 'PRIVILEGE_ESCALATION', 'تعیین شماره 09111273476 به عنوان مالک و مدیر ارشد پروژه (Super Admin)', 'USER', '1', '127.0.0.1', 'Karovita-Core/2.4', 'SUCCESS', 1, NOW()),
(2, 1, 'اردلان داوودی (مدیر ارشد)', '09111273476', 'admin', 'CONFIGURATION_CHANGE', 'بارگذاری و پیکربندی اولیه ماژول‌ها و تب‌های پیش‌فرض ERP کارویتا', 'CONFIG_SETTINGS', 'SYSTEM_BOOTSTRAP', '127.0.0.1', 'Karovita-Core/2.4', 'SUCCESS', 1, NOW());

-- -------------------------------------------------------------
-- 19. OTP CODES TABLE (Authentication Codes)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `otp_codes`;
CREATE TABLE `otp_codes` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `mobile` VARCHAR(15) NOT NULL,
  `code` VARCHAR(10) NOT NULL,
  `code_hash` VARCHAR(255) NULL,
  `purpose` VARCHAR(20) NOT NULL DEFAULT 'login',
  `status` VARCHAR(20) NOT NULL DEFAULT 'sent',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `attempts` INT UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` BIGINT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_otp_codes_mobile` (`mobile`),
  KEY `idx_otp_codes_status` (`status`),
  KEY `idx_otp_codes_is_active` (`is_active`),
  KEY `idx_otp_codes_expires_at` (`expires_at`),
  KEY `idx_otp_codes_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `otp_codes` (`id`, `mobile`, `code`, `code_hash`, `purpose`, `status`, `is_active`, `attempts`, `expires_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '09111273476', '16157', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-10 06:10:25', '2026-09-10 06:10:25', NULL),
(2, '09111273476', '81861', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-10 06:13:34', '2026-09-10 06:13:34', NULL),
(6, '09113137018', '49078', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-14 05:20:13', '2026-09-14 05:20:13', NULL),
(7, '09111273476', '88443', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-14 05:50:22', '2026-09-14 05:50:22', NULL),
(8, '09113137018', '36890', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-14 05:53:40', '2026-09-14 05:53:40', NULL),
(9, '09111273476', '13342', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-14 08:39:42', '2026-09-14 08:39:42', NULL),
(10, '09113175211', '70006', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-14 08:40:16', '2026-09-14 08:40:16', NULL),
(12, '09210895901', '17223', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-15 10:43:46', '2026-09-15 10:43:46', NULL),
(14, '09111273476', '19693', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-15 11:19:34', '2026-09-15 11:19:34', NULL),
(17, '09012207286', '77571', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-15 12:24:39', '2026-09-15 12:24:39', NULL),
(19, '09113162780', '99818', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-15 13:19:33', '2026-09-15 13:19:33', NULL),
(21, '09113162780', '60963', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-15 19:36:07', '2026-09-15 19:36:07', NULL),
(25, '09114995930', '37948', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 07:00:31', '2026-09-16 07:00:31', NULL),
(26, '09128066062', '25347', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 07:06:21', '2026-09-16 07:06:21', NULL),
(27, '09111273476', '13791', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 07:43:34', '2026-09-16 07:43:34', NULL),
(28, '09128066062', '47609', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 08:08:42', '2026-09-16 08:08:42', NULL),
(29, '09128066062', '27894', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 08:09:59', '2026-09-16 08:09:59', NULL),
(30, '09339945047', '45254', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 08:56:49', '2026-09-16 08:56:49', NULL),
(31, '09111273476', '62061', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 09:12:35', '2026-09-16 09:12:35', NULL),
(32, '09114995930', '39540', NULL, 'login', 'sent', 1, 0, 2026, '2026-09-16 11:01:41', '2026-09-16 11:01:41', NULL);


-- -------------------------------------------------------------
-- 20. AUTH TOKENS TABLE (Bearer Sessions)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `auth_tokens`;
CREATE TABLE `auth_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `token` VARCHAR(128) NOT NULL,
  `expires_at` TIMESTAMP NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_tokens_token_unique` (`token`),
  KEY `idx_auth_tokens_user_id` (`user_id`),
  KEY `idx_auth_tokens_status` (`status`),
  KEY `idx_auth_tokens_is_active` (`is_active`),
  KEY `idx_auth_tokens_expires_at` (`expires_at`),
  KEY `idx_auth_tokens_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- 21. ERROR LOGS TABLE (Monitoring & Crash Logs)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `error_logs`;
CREATE TABLE `error_logs` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `message` TEXT NOT NULL,
  `name` VARCHAR(191) NULL,
  `stack` MEDIUMTEXT NULL,
  `context` JSON NULL,
  `url` VARCHAR(255) NULL,
  `level` VARCHAR(50) NOT NULL DEFAULT 'error',
  `source` VARCHAR(50) NOT NULL DEFAULT 'server',
  `resolved` TINYINT(1) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'unresolved',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  KEY `idx_error_logs_level` (`level`),
  KEY `idx_error_logs_source` (`source`),
  KEY `idx_error_logs_resolved` (`resolved`),
  KEY `idx_error_logs_status` (`status`),
  KEY `idx_error_logs_is_active` (`is_active`),
  KEY `idx_error_logs_created_at` (`created_at`),
  KEY `idx_error_logs_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- 22. PUSH SUBSCRIPTIONS TABLE (WebPush PWA Devices)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `push_subscriptions`;
CREATE TABLE `push_subscriptions` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `user_mobile` VARCHAR(50) NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'guest',
  `endpoint` TEXT NOT NULL,
  `p256dh` VARCHAR(255) NOT NULL,
  `auth` VARCHAR(255) NOT NULL,
  `device_type` VARCHAR(50) NOT NULL DEFAULT 'desktop',
  `user_agent` TEXT NULL,
  `ip_address` VARCHAR(100) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  KEY `idx_push_subscriptions_user_id` (`user_id`),
  KEY `idx_push_subscriptions_role` (`role`),
  KEY `idx_push_subscriptions_status` (`status`),
  KEY `idx_push_subscriptions_is_active` (`is_active`),
  KEY `idx_push_subscriptions_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- 22.1 PWA SETTINGS TABLE (Master Switch for PWA & Web Push)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `pwa_settings`;
CREATE TABLE `pwa_settings` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `updated_by` VARCHAR(191) NULL DEFAULT 'admin',
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pwa_settings` (`id`, `enabled`, `updated_by`) VALUES (1, 1, 'system');

-- -------------------------------------------------------------
-- 23. WEB VITALS TABLE (Core Web Vitals Performance Metrics)
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `web_vitals`;
CREATE TABLE `web_vitals` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `value` FLOAT NOT NULL DEFAULT 0,
  `rating` VARCHAR(20) NOT NULL DEFAULT 'good',
  `delta` FLOAT NOT NULL DEFAULT 0,
  `metric_id` VARCHAR(100) NULL,
  `navigation_type` VARCHAR(50) NULL,
  `page_url` VARCHAR(255) NULL,
  `user_agent` TEXT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'recorded',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  KEY `idx_web_vitals_name` (`name`),
  KEY `idx_web_vitals_rating` (`rating`),
  KEY `idx_web_vitals_status` (`status`),
  KEY `idx_web_vitals_is_active` (`is_active`),
  KEY `idx_web_vitals_created_at` (`created_at`),
  KEY `idx_web_vitals_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- 24. SYSTEM MIGRATIONS TRACKER
-- -------------------------------------------------------------
DROP TABLE IF EXISTS `sys_migrations`;
CREATE TABLE `sys_migrations` (
  `migration` VARCHAR(64) PRIMARY KEY,
  `status` VARCHAR(20) NOT NULL DEFAULT 'executed',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  KEY `idx_sys_migrations_status` (`status`),
  KEY `idx_sys_migrations_is_active` (`is_active`),
  KEY `idx_sys_migrations_created_at` (`created_at`),
  KEY `idx_sys_migrations_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sys_migrations` (`migration`) VALUES 
('v7_schema_complete'),
('v8_subscription_heal'),
('v9_enterprise_standards_complete');

SET FOREIGN_KEY_CHECKS = 1;
