-- ==============================================================================
-- KaroVita Cloud ERP - Production Database Instant Update Script
-- اسکریپت بروزرسانی سریع و بدون نقص پایگاه داده کارویتا در هاست پروداکشن
-- ==============================================================================
-- این اسکریپت بدون پاک کردن داده‌های فعلی شما، تنظیمات درگاه شاپرک زیبال و دسترسی کارشناس پشتیبانی را بروزرسانی می‌کند.
-- جهت اجرا: وارد phpMyAdmin هاست خود شوید، دیتابیس را انتخاب کرده و در تب SQL این دستورات را اجرا (Go) نمایید.
-- ==============================================================================

-- ۱. فعال‌سازی حالت پروداکشن درگاه زیبال شاپرک و ثبت کد مرچنت رسمی
INSERT INTO `gateway_settings` (
  `id`, `zibal_merchant`, `zibal_sandbox`, `zibal_enabled`, 
  `sms_provider`, `sms_api_key`, `sms_line_number`, `sms_template_otp`, `sms_param_name`, 
  `sms_templates_json`, `sms_sandbox`, `sms_enabled`, `status`, `is_active`, `updated_at`
) VALUES (
  1, 
  '6a5f37d32884aa3809632821', 
  0, 
  1, 
  'sms_ir', 
  'ocv39CACg6Vg3cg3DbY3mUwfOti7dktYUwksl3jA3Jt1qI0z', 
  '30007732', 
  '418155', 
  'CODE', 
  '{"otp":418155,"invoice_issued":418155,"sub_expiring_7days":418157,"sub_expiring_3days":418158,"ticket_created":418159,"payment_success":418155}', 
  0, 
  1, 
  'active', 
  1, 
  NOW()
)
ON DUPLICATE KEY UPDATE
  `zibal_merchant` = '6a5f37d32884aa3809632821',
  `zibal_sandbox` = 0,
  `zibal_enabled` = 1,
  `sms_provider` = 'sms_ir',
  `sms_api_key` = 'ocv39CACg6Vg3cg3DbY3mUwfOti7dktYUwksl3jA3Jt1qI0z',
  `sms_line_number` = '30007732',
  `sms_template_otp` = '418155',
  `sms_templates_json` = '{"otp":418155,"invoice_issued":418155,"sub_expiring_7days":418157,"sub_expiring_3days":418158,"ticket_created":418159,"payment_success":418155}',
  `sms_sandbox` = 0,
  `sms_enabled` = 1,
  `updated_at` = NOW();

-- ۲. اطمینان از وجود ستون has_used_trial در جدول کاربران جهت ثبت تاریخچه دوره‌های آزمایشی
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `has_used_trial` TINYINT(1) NOT NULL DEFAULT 0;

-- ۳. اطمینان از صحت دسترسی مدیر ارشد سیستم (09111273476)
UPDATE `users` SET `role` = 'admin', `status` = 'active', `is_active` = 1 WHERE `mobile` = '09111273476';

-- ۴. اطمینان از وجود ستون‌های اختصاصی ارتقا و افزودن ماژول در جدول سفارش‌ها
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `is_resource_addon` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `order_type` VARCHAR(50) NOT NULL DEFAULT 'order';
ALTER TABLE `orders` ADD COLUMN IF NOT EXISTS `subscription_id` BIGINT UNSIGNED NULL;

-- ۵. بررسی و فعال‌سازی ستون‌های مورد نیاز در جداول سفارش‌ها، اشتراک‌ها و تراکنش‌ها
ALTER TABLE `orders` MODIFY COLUMN `status` VARCHAR(50) NOT NULL DEFAULT 'pending';
ALTER TABLE `transactions` MODIFY COLUMN `gateway` VARCHAR(50) NOT NULL DEFAULT 'zibal';

-- ۶. یکپارچه‌سازی و رفع ابهام وضعیت اشتراک‌های فعال کاربران
-- تضمین می‌کند که تمامی اشتراک‌های معتبر با وضعیت استاندارد 'active' و 'is_active = 1' در سیستم فعال باشند
UPDATE `subscriptions` 
SET `status` = 'active', `is_active` = 1 
WHERE (`status` IN ('completed', 'paid', 'Active', '1', 'active') OR `is_active` = 1) 
  AND (`expires_at` IS NULL OR `expires_at` > NOW())
  AND `deleted_at` IS NULL;

SELECT 'عملیات بروزرسانی پایگاه‌داده با موفقیت کامل انجام شد.' AS `Result`;
